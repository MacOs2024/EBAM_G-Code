"""EBAM G-code Studio core v4.2.

STL/DXF/CSV -> layer slicing -> EBAM-oriented G-code.
Designed for Bormash/FABMETALL-style electron-beam wire deposition.

This is an engineering generator, not certified process qualification.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, replace
from pathlib import Path
from typing import Callable, Iterable, List, Tuple, Dict, Any, Optional
import csv
import io
import json
import math

import numpy as np
import trimesh

try:
    from shapely.geometry import LineString, MultiLineString, GeometryCollection, Polygon, MultiPolygon, Point as ShapelyPoint
    from shapely import unary_union
    from shapely.ops import polygonize
except Exception as exc:  # pragma: no cover
    raise RuntimeError("Shapely is required. Install dependencies from requirements.txt") from exc

Point = Tuple[float, float]
Segment = Tuple[float, float, float, float]


MATERIAL_LIBRARY: Dict[str, Dict[str, float | str]] = {
    "stainless_steel_12_wire": {
        "name_ru": "Нержавеющая сталь, проволока 1.2 мм",
        "density_g_cm3": 7.9,
        "wire_diameter_mm": 1.2,
        "energy_bottom_j_mm": 158.0,
        "energy_top_j_mm": 138.0,
        "note_ru": "Базовый профиль по вашим опытам V16-V21."
    },
    "steel_generic": {
        "name_ru": "Сталь, общий стартовый профиль",
        "density_g_cm3": 7.85,
        "wire_diameter_mm": 1.2,
        "energy_bottom_j_mm": 160.0,
        "energy_top_j_mm": 140.0,
        "note_ru": "Консервативный старт для стали."
    },
    "titanium_generic": {
        "name_ru": "Титан/сплав титана, осторожный профиль",
        "density_g_cm3": 4.5,
        "wire_diameter_mm": 1.2,
        "energy_bottom_j_mm": 145.0,
        "energy_top_j_mm": 125.0,
        "note_ru": "Требует отдельной квалификации по материалу и вакууму."
    },
    "bronze_experimental": {
        "name_ru": "Бронза, экспериментальный профиль",
        "density_g_cm3": 8.7,
        "wire_diameter_mm": 1.2,
        "energy_bottom_j_mm": 125.0,
        "energy_top_j_mm": 110.0,
        "note_ru": "Высокий риск испарения/брызг; только после короткого теста."
    },
}


@dataclass
class ProcessSettings:
    # Geometry/slicing
    layer_height: float = 0.30              # mm
    hatch_spacing: float = 2.0              # mm
    edge_offset: float = 0.80               # mm inward from polygon boundary
    min_segment_length: float = 4.0         # mm
    center_xy: bool = False                 # if False -> shift min X/Y to 0
    z_to_zero: bool = True
    # Geometry orientation / placement. Applied before XY/Z normalization.
    # axis_order means which original axes become output X/Y/Z, e.g. "XZY" makes output Y from original Z.
    axis_order: str = "XYZ"
    rotate_x_deg: float = 0.0
    rotate_y_deg: float = 0.0
    rotate_z_deg: float = 0.0
    mirror_x: bool = False
    mirror_y: bool = False
    mirror_z: bool = False
    output_offset_x_mm: float = 0.0
    output_offset_y_mm: float = 0.0
    output_offset_z_mm: float = 0.0
    direction: str = "Y-"                   # Y-, Y+, X-, X+
    alternate_hatch_shift: bool = True
    shift_fraction_a: float = 0.00
    shift_fraction_b: float = 0.33
    shift_fraction_c: float = -0.33
    thermal_ordering: str = "skip_neighbours"  # natural or skip_neighbours
    contour_passes: int = 0                 # number of perimeter passes per layer
    contour_offset_step: float = 0.70       # mm between contour passes inward
    contour_wire_factor: float = 0.72       # contour wire relative to hatch
    contour_feed_factor: float = 0.88       # contour feed relative to hatch
    contour_every_n_layers: int = 1         # 1 = every layer, 2 = each second layer
    contour_first: bool = False             # False: hatch then contour; True: contour then hatch

    # Thin-wall / complex STL recovery
    adaptive_thin_wall: bool = True          # retry thinner settings when a layer has no hatch
    force_contour_on_empty_layers: bool = True # add contour-only path if hatch disappears
    adaptive_section_probe: bool = True       # retry nearby Z sections when STL slice is numerically empty
    section_probe_fraction: float = 0.45      # max +/- layer_height fraction for nearby STL slicing
    thin_wall_hatch_spacing_factor: float = 0.55
    thin_wall_edge_offset_factor: float = 0.35
    thin_wall_min_segment_length: float = 1.00
    thin_wall_wire_factor: float = 0.65       # wire reduction for contour-only thin-wall fallback
    adaptive_wire_correction: bool = True     # reduce wire feed when adaptive hatch spacing is smaller
    manual_section_fallback: bool = True      # offline-safe triangle/plane section fallback, independent of rtree
    projection_fallback_if_empty: bool = True # last-resort 2.5D projection fallback instead of empty G-code
    minimum_generated_layer_fraction: float = 0.90
    max_layers_to_generate: int = 0             # 0 = full part; >0 = first N layers only for test files

    # UI/performance controls
    progress_update_every_layers: int = 1       # progress callback granularity for Streamlit UI

    # Target-time calculation. These are advisory/metadata fields used by UI and audit.
    # The generator still follows the actual feed/layer/hatch/current settings below.
    target_total_time_s: float = 0.0            # 0 = no target time
    target_time_mode: str = "off"              # off / feed_only / feed_layer_hatch

    # EBAM process calculation
    voltage_kv: float = 60.0
    target_energy_bottom_j_per_mm: float = 158.0
    target_energy_top_j_per_mm: float = 138.0
    feed_bottom_mm_min: float = 650.0
    feed_top_mm_min: float = 710.0
    wire_diameter_mm: float = 1.2
    deposition_efficiency: float = 1.00      # 1.00 means all wire volume becomes bead
    density_g_cm3: float = 7.9
    focus_ma: float = 1030.0
    current_min_ma: float = 8.0
    current_max_ma: float = 35.0
    wire_min_mm_s: float = 0.3
    wire_max_mm_s: float = 25.0          # soft warning threshold, not a hard clamp

    # Start/end shaping
    z_hop_mm: float = 7.0
    lead_in_beam_mm: float = 0.6
    soft_start_mm: float = 2.0
    soft_finish_mm: float = 1.8
    tail_beam_mm: float = 0.8
    soft_wire_factor: float = 0.82
    edge_wire_factor_bottom: float = 0.94
    edge_wire_factor_top: float = 0.87
    near_edge_wire_factor_bottom: float = 0.97
    near_edge_wire_factor_top: float = 0.93
    use_w_retract: bool = True
    w_retract_mm: float = 0.80
    w_retract_feed_mm_min: float = 720.0
    use_m68_speed_retract: bool = False
    speed_retract_mm_s: float = 3.6
    speed_retract_time_s: float = 0.22

    # Pauses
    beam_preheat_s: float = 0.030
    wire_settle_s: float = 0.020
    beam_off_pause_s: float = 0.030
    layer_pause_bottom_s: float = 0.10
    layer_pause_top_s: float = 0.45

    # Output/safety
    g64_tolerance_mm: float = 0.08
    safe_z_final_mm: float = 110.0
    rapid_feed_z_mm_min: float = 900.0
    work_z_feed_mm_min: float = 240.0
    units: str = "mm"
    machine_name: str = "Bormash EBAM"
    include_comments: bool = True
    max_gcode_lines_warning: int = 500000
    max_gcode_size_mb_warning: float = 20.0

    def wire_area_mm2(self) -> float:
        return math.pi * self.wire_diameter_mm ** 2 / 4.0


@dataclass
class LayerInfo:
    index: int
    z: float
    z_next: float
    ratio: float
    current_ma: float
    feed_mm_min: float
    travel_speed_mm_s: float
    wire_mm_s: float
    energy_j_mm: float
    energy_j_mm3: float
    layer_pause_s: float
    segments_count: int = 0
    contour_segments_count: int = 0
    path_length_mm: float = 0.0
    contour_length_mm: float = 0.0


@dataclass
class AuditResult:
    ok: bool
    messages: List[str]
    stats: Dict[str, Any]


@dataclass
class GenerationResult:
    gcode: str
    layer_csv: str
    audit_text: str
    stats: Dict[str, Any]


def load_mesh_any(stl_path: str | Path) -> trimesh.Trimesh:
    mesh = trimesh.load_mesh(str(stl_path), force="mesh")
    if isinstance(mesh, trimesh.Scene):
        geoms = [g for g in mesh.geometry.values() if isinstance(g, trimesh.Trimesh)]
        if not geoms:
            raise ValueError("STL/scene contains no mesh geometry")
        mesh = trimesh.util.concatenate(geoms)
    if not isinstance(mesh, trimesh.Trimesh):
        raise ValueError("File is not a valid triangular mesh")
    if mesh.faces.size == 0 or mesh.vertices.size == 0:
        raise ValueError("Mesh is empty")
    return mesh.copy()


def _normalise_axis_order(axis_order: str) -> str:
    order = (axis_order or "XYZ").upper().replace(" ", "")
    if len(order) != 3 or sorted(order) != ["X", "Y", "Z"]:
        return "XYZ"
    return order


def _apply_mesh_orientation(mesh: trimesh.Trimesh, settings: ProcessSettings) -> trimesh.Trimesh:
    """Apply user-selected STL orientation before normal XY/Z placement.

    This solves the common CAD/STL problem where a model is exported on the wrong
    side or with the build height along X/Y instead of Z.
    """
    m = mesh.copy()
    order = _normalise_axis_order(getattr(settings, "axis_order", "XYZ"))
    axis_index = {"X": 0, "Y": 1, "Z": 2}
    idx = [axis_index[a] for a in order]
    if idx != [0, 1, 2]:
        verts = np.asarray(m.vertices, dtype=float).copy()
        m.vertices = verts[:, idx]

    mirror = np.array([
        -1.0 if getattr(settings, "mirror_x", False) else 1.0,
        -1.0 if getattr(settings, "mirror_y", False) else 1.0,
        -1.0 if getattr(settings, "mirror_z", False) else 1.0,
    ], dtype=float)
    if not np.allclose(mirror, 1.0):
        verts = np.asarray(m.vertices, dtype=float).copy()
        m.vertices = verts * mirror
        # Mirroring changes handedness; normals are not trusted afterwards.
        try:
            m.fix_normals()
        except Exception:
            pass

    def rot(angle_deg: float, axis: Tuple[float, float, float]):
        try:
            a = math.radians(float(angle_deg))
        except Exception:
            a = 0.0
        if abs(a) > 1e-12:
            m.apply_transform(trimesh.transformations.rotation_matrix(a, axis, point=[0.0, 0.0, 0.0]))

    rot(getattr(settings, "rotate_x_deg", 0.0), (1.0, 0.0, 0.0))
    rot(getattr(settings, "rotate_y_deg", 0.0), (0.0, 1.0, 0.0))
    rot(getattr(settings, "rotate_z_deg", 0.0), (0.0, 0.0, 1.0))
    return m


def normalize_mesh(mesh: trimesh.Trimesh, settings: ProcessSettings) -> trimesh.Trimesh:
    m = _apply_mesh_orientation(mesh, settings)
    bounds = m.bounds.copy()
    shift = np.zeros(3)
    if settings.center_xy:
        center_xy = (bounds[0, :2] + bounds[1, :2]) / 2.0
        shift[0] = -center_xy[0]
        shift[1] = -center_xy[1]
    else:
        shift[0] = -bounds[0, 0]
        shift[1] = -bounds[0, 1]
    if settings.z_to_zero:
        shift[2] = -bounds[0, 2]
    m.apply_translation(shift)
    m.apply_translation([
        float(getattr(settings, "output_offset_x_mm", 0.0)),
        float(getattr(settings, "output_offset_y_mm", 0.0)),
        float(getattr(settings, "output_offset_z_mm", 0.0)),
    ])
    return m

def mesh_summary(mesh: trimesh.Trimesh) -> Dict[str, float]:
    b = mesh.bounds
    ext = b[1] - b[0]
    return {
        "min_x": float(b[0, 0]), "max_x": float(b[1, 0]),
        "min_y": float(b[0, 1]), "max_y": float(b[1, 1]),
        "min_z": float(b[0, 2]), "max_z": float(b[1, 2]),
        "size_x": float(ext[0]), "size_y": float(ext[1]), "size_z": float(ext[2]),
        "volume_mm3": float(abs(mesh.volume)) if mesh.is_volume else float("nan"),
        "area_mm2": float(mesh.area),
        "is_watertight": bool(mesh.is_watertight),
        "source_type": "STL",
    }


def polygon_summary(polys: List[Polygon], height: float) -> Dict[str, float]:
    u = unary_union(polys) if len(polys) > 1 else polys[0]
    minx, miny, maxx, maxy = u.bounds
    area = float(u.area)
    return {
        "min_x": float(minx), "max_x": float(maxx),
        "min_y": float(miny), "max_y": float(maxy),
        "min_z": 0.0, "max_z": float(height),
        "size_x": float(maxx - minx), "size_y": float(maxy - miny), "size_z": float(height),
        "volume_mm3": float(area * height),
        "area_mm2": float(area),
        "is_watertight": True,
        "source_type": "2D contour",
    }




def _regular_polygon_points(cx: float, cy: float, radius: float, n: int, rotation_deg: float = 0.0) -> List[Point]:
    n = max(3, int(n))
    rot = math.radians(rotation_deg)
    return [
        (cx + radius * math.cos(rot + 2.0 * math.pi * i / n),
         cy + radius * math.sin(rot + 2.0 * math.pi * i / n))
        for i in range(n)
    ]


def create_standard_shape_polygons(shape_type: str, params: Dict[str, Any]) -> List[Polygon]:
    """Create simple 2D standard shapes as Shapely polygons.

    The coordinate convention is EBAM-friendly: if center_xy is false later,
    shapes will be shifted so min X/Y = 0 before G-code generation.
    """
    stype = (shape_type or "rectangle").strip().lower()
    resolution = int(params.get("resolution", 96))
    resolution = max(16, min(resolution, 512))

    def v(name: str, default: float) -> float:
        try:
            return float(params.get(name, default))
        except Exception:
            return float(default)

    def clean(poly) -> List[Polygon]:
        return _clean_polygons([poly])

    if stype in ["rectangle", "rect", "прямоугольник"]:
        sx = max(v("width_x", 20.0), 0.01)
        sy = max(v("length_y", 100.0), 0.01)
        return clean(Polygon([(0, 0), (sx, 0), (sx, sy), (0, sy)]))

    if stype in ["square", "квадрат"]:
        a = max(v("side", 50.0), 0.01)
        return clean(Polygon([(0, 0), (a, 0), (a, a), (0, a)]))

    if stype in ["circle", "круг", "cylinder"]:
        r = max(v("radius", 25.0), 0.01)
        return clean(ShapelyPoint(0, 0).buffer(r, resolution=resolution))

    if stype in ["ring", "annulus", "кольцо"]:
        ro = max(v("outer_radius", 30.0), 0.01)
        ri = max(v("inner_radius", 20.0), 0.0)
        if ri >= ro:
            ri = ro * 0.65
        outer = ShapelyPoint(0, 0).buffer(ro, resolution=resolution)
        inner = ShapelyPoint(0, 0).buffer(ri, resolution=resolution)
        return clean(outer.difference(inner))

    if stype in ["ellipse", "эллипс"]:
        rx = max(v("radius_x", 40.0), 0.01)
        ry = max(v("radius_y", 20.0), 0.01)
        from shapely.affinity import scale
        return clean(scale(ShapelyPoint(0, 0).buffer(1.0, resolution=resolution), xfact=rx, yfact=ry, origin=(0, 0)))

    if stype in ["triangle", "треугольник"]:
        base = max(v("base", 60.0), 0.01)
        height = max(v("triangle_height", 50.0), 0.01)
        # Isosceles triangle, base along X, tip toward +Y.
        return clean(Polygon([(0.0, 0.0), (base, 0.0), (base / 2.0, height)]))

    if stype in ["regular_polygon", "polygon", "многоугольник"]:
        n = max(3, int(params.get("sides", 6)))
        r = max(v("radius", 30.0), 0.01)
        rot = v("rotation_deg", 0.0)
        return clean(Polygon(_regular_polygon_points(0.0, 0.0, r, n, rot)))

    if stype in ["star", "звезда"]:
        points = max(3, int(params.get("points", 5)))
        ro = max(v("outer_radius", 35.0), 0.01)
        ri = max(v("inner_radius", 17.0), 0.01)
        rot = math.radians(v("rotation_deg", -90.0))
        coords: List[Point] = []
        for i in range(points * 2):
            r = ro if i % 2 == 0 else min(ri, ro * 0.95)
            a = rot + math.pi * i / points
            coords.append((r * math.cos(a), r * math.sin(a)))
        return clean(Polygon(coords))

    if stype in ["capsule", "rounded_slot", "овал-капсула", "капсула"]:
        length = max(v("length_y", 100.0), 0.01)
        width = max(v("width_x", 20.0), 0.01)
        r = width / 2.0
        if length <= width:
            return clean(ShapelyPoint(0, 0).buffer(r, resolution=resolution))
        from shapely.geometry import LineString
        return clean(LineString([(0.0, r), (0.0, length - r)]).buffer(r, resolution=resolution))

    raise ValueError(f"Unsupported standard shape: {shape_type}")

def _transform_poly_to_xy(poly, transform):
    """Convert Path2D polygon coordinates back into original XY using section transform."""
    def conv(coords):
        out = []
        for u, v in coords:
            vec = np.array([float(u), float(v), 0.0, 1.0])
            xyz = transform.dot(vec)[:3]
            out.append((float(xyz[0]), float(xyz[1])))
        return out
    exterior = conv(poly.exterior.coords)
    interiors = [conv(r.coords) for r in poly.interiors]
    return Polygon(exterior, interiors)


def _fallback_polygons_from_closed(path2d, transform):
    """Build polygons from closed rings without requiring rtree.

    trimesh Path2D.polygons_full may require the optional rtree package to
    classify holes. On many Windows installs rtree is missing, which used to
    produce an empty toolpath for valid STL sections with inner holes (for
    example bowl/cup shapes). This fallback uses polygons_closed and rebuilds
    simple parent/child hole relationships with shapely only.
    """
    try:
        raw = list(path2d.polygons_closed)
    except Exception:
        raw = []
    rings = []
    for p in raw:
        try:
            q = _transform_poly_to_xy(p, transform)
        except Exception:
            q = p
        if q is None or q.is_empty:
            continue
        try:
            if not q.is_valid:
                q = q.buffer(0)
        except Exception:
            continue
        if isinstance(q, Polygon) and q.area > 1e-6:
            rings.append(q)
        elif isinstance(q, MultiPolygon):
            rings.extend([g for g in q.geoms if g.area > 1e-6])

    if not rings:
        return []

    # Sort by area: largest rings are probable exteriors. For each ring,
    # choose the smallest larger ring that contains it as a parent. Odd-even
    # nesting is simplified here; this handles typical STL slices with outer
    # loops and holes robustly enough for EBAM path generation.
    rings = sorted(rings, key=lambda p: p.area, reverse=True)
    parents = [None] * len(rings)
    for i, child in enumerate(rings):
        cpt = child.representative_point()
        best = None
        best_area = float('inf')
        for j, parent in enumerate(rings[:i]):
            try:
                if parent.contains(cpt) and parent.area < best_area:
                    best = j
                    best_area = parent.area
            except Exception:
                pass
        parents[i] = best

    result = []
    for i, ring in enumerate(rings):
        # Exterior rings have no parent. Rings with a parent become holes of
        # that parent. Nested islands are rare for our EBAM use case; if found
        # they will be treated as separate exteriors by even-depth rule.
        depth = 0
        pidx = parents[i]
        while pidx is not None:
            depth += 1
            pidx = parents[pidx]
        if depth % 2 != 0:
            continue
        holes = []
        for k, other in enumerate(rings):
            if parents[k] == i:
                try:
                    holes.append(list(other.exterior.coords))
                except Exception:
                    pass
        try:
            poly = Polygon(list(ring.exterior.coords), holes)
            if not poly.is_valid:
                poly = poly.buffer(0)
            if isinstance(poly, Polygon) and poly.area > 1e-6:
                result.append(poly)
            elif isinstance(poly, MultiPolygon):
                result.extend([g for g in poly.geoms if g.area > 1e-6])
        except Exception:
            result.append(ring)
    return result



def _rings_to_polygons(rings: List[Polygon]) -> List[Polygon]:
    """Convert independent closed rings to polygons with holes using containment.

    This deliberately avoids rtree. It is slower than Trimesh's polygons_full,
    but robust for offline Windows installations where optional spatial-index
    wheels are absent.
    """
    clean = []
    for q in rings:
        if q is None or q.is_empty:
            continue
        try:
            if not q.is_valid:
                q = q.buffer(0)
        except Exception:
            continue
        if isinstance(q, Polygon) and q.area > 1e-6:
            clean.append(q)
        elif isinstance(q, MultiPolygon):
            clean.extend([g for g in q.geoms if g.area > 1e-6])
    if not clean:
        return []

    clean = sorted(clean, key=lambda p: p.area, reverse=True)
    parents = [None] * len(clean)
    for i, child in enumerate(clean):
        cpt = child.representative_point()
        best = None
        best_area = float("inf")
        for j, parent in enumerate(clean[:i]):
            try:
                if parent.contains(cpt) and parent.area < best_area:
                    best = j
                    best_area = parent.area
            except Exception:
                pass
        parents[i] = best

    result = []
    for i, ring in enumerate(clean):
        depth = 0
        pidx = parents[i]
        while pidx is not None:
            depth += 1
            pidx = parents[pidx]
        if depth % 2 != 0:
            continue
        holes = []
        for k, other in enumerate(clean):
            if parents[k] == i:
                try:
                    holes.append(list(other.exterior.coords))
                except Exception:
                    pass
        try:
            poly = Polygon(list(ring.exterior.coords), holes)
            if not poly.is_valid:
                poly = poly.buffer(0)
            if isinstance(poly, Polygon) and poly.area > 1e-6:
                result.append(poly)
            elif isinstance(poly, MultiPolygon):
                result.extend([g for g in poly.geoms if g.area > 1e-6])
        except Exception:
            result.append(ring)
    return _clean_polygons(result)


def _fallback_polygons_from_discrete(path2d, transform) -> List[Polygon]:
    """Build polygons from Path2D.discrete without polygons_full/polygons_closed.

    This is the v3.1 offline fallback. It only needs Shapely and Numpy and
    avoids the optional rtree dependency entirely.
    """
    rings: List[Polygon] = []
    try:
        curves = list(path2d.discrete)
    except Exception:
        curves = []
    for arr in curves:
        try:
            pts = [(float(a[0]), float(a[1])) for a in arr]
        except Exception:
            continue
        if len(pts) < 4:
            continue
        if math.hypot(pts[0][0] - pts[-1][0], pts[0][1] - pts[-1][1]) > 1e-4:
            pts.append(pts[0])
        try:
            p2 = Polygon(pts)
            q = _transform_poly_to_xy(p2, transform)
            if not q.is_valid:
                q = q.buffer(0)
            if isinstance(q, Polygon) and q.area > 1e-6:
                rings.append(q)
            elif isinstance(q, MultiPolygon):
                rings.extend([g for g in q.geoms if g.area > 1e-6])
        except Exception:
            continue
    return _rings_to_polygons(rings)


def _manual_section_polygons_at_z(mesh: trimesh.Trimesh, z: float) -> List[Polygon]:
    """Manual triangle-plane intersection fallback for STL slicing.

    Trimesh section polygonization may fail on some offline Windows machines
    depending on optional packages. This routine intersects mesh triangles
    with a horizontal plane directly, polygonizes resulting XY linework with
    Shapely, and reconstructs holes. It is slower but very robust.
    """
    try:
        verts = np.asarray(mesh.vertices, dtype=float)
        faces = np.asarray(mesh.faces, dtype=np.int64)
    except Exception:
        return []
    if len(faces) == 0:
        return []
    z = float(z)
    eps = 1e-7
    tri = verts[faces]
    zvals = tri[:, :, 2]
    zmin = zvals.min(axis=1)
    zmax = zvals.max(axis=1)
    mask = (zmin <= z + eps) & (zmax >= z - eps) & ((zmax - zmin) > eps)
    if not np.any(mask):
        return []
    lines = []
    for t in tri[mask]:
        pts = []
        for i, j in ((0, 1), (1, 2), (2, 0)):
            p0 = t[i]
            p1 = t[j]
            z0 = p0[2]
            z1 = p1[2]
            dz = z1 - z0
            # edge lies in the plane; keep both endpoints as a segment candidate
            if abs(z0 - z) <= eps and abs(z1 - z) <= eps:
                pts.append((float(p0[0]), float(p0[1])))
                pts.append((float(p1[0]), float(p1[1])))
                continue
            if abs(dz) <= eps:
                continue
            if (z0 - z) * (z1 - z) <= eps:
                u = (z - z0) / dz
                if -1e-7 <= u <= 1.0 + 1e-7:
                    x = p0[0] + u * (p1[0] - p0[0])
                    y = p0[1] + u * (p1[1] - p0[1])
                    pts.append((float(x), float(y)))
        # dedupe points from vertices exactly on plane
        uniq = []
        seen = set()
        for x, y in pts:
            key = (round(x, 5), round(y, 5))
            if key not in seen:
                seen.add(key)
                uniq.append((x, y))
        if len(uniq) >= 2:
            a, b = uniq[0], uniq[1]
            if math.hypot(a[0] - b[0], a[1] - b[1]) > 1e-5:
                try:
                    # Snap coordinates to 1 µm to help polygonize close loops.
                    a2 = (round(a[0], 6), round(a[1], 6))
                    b2 = (round(b[0], 6), round(b[1], 6))
                    lines.append(LineString([a2, b2]))
                except Exception:
                    pass
    if not lines:
        return []
    try:
        merged = unary_union(lines)
        polys = [p for p in polygonize(merged) if isinstance(p, Polygon) and p.area > 1e-6]
    except Exception:
        return []
    if not polys:
        return []

    # Shapely polygonize of an annulus often returns both the annulus polygon
    # and the filled inner hole polygon.  Drop polygons that sit inside a hole
    # of another polygon, otherwise a hollow cup slice becomes a filled disk.
    filtered: List[Polygon] = []
    for i, p in enumerate(polys):
        rp = p.representative_point()
        inside_some_hole = False
        for j, q in enumerate(polys):
            if i == j or not getattr(q, "interiors", None):
                continue
            try:
                for ring in q.interiors:
                    if Polygon(ring).contains(rp):
                        inside_some_hole = True
                        break
            except Exception:
                pass
            if inside_some_hole:
                break
        if not inside_some_hole:
            filtered.append(p)
    return _clean_polygons(filtered)

def _path2d_polygons(section: trimesh.path.Path3D):
    if section is None:
        return []
    try:
        path2d, transform = section.to_2D()
    except Exception:
        path2d, transform = section.to_planar()

    # First try Trimesh's full polygon reconstruction. On some Windows
    # combinations polygons_full may fail OR silently return an empty list
    # even when polygons_closed contains valid rings.  A silent empty list is
    # exactly what made the preview look blank for valid STL models.
    polys = []
    try:
        polys = list(path2d.polygons_full)
    except Exception:
        # Common on Windows if optional rtree dependency is absent.
        # Fallback keeps STL generation working without installing rtree.
        polys = _fallback_polygons_from_closed(path2d, transform)
        if not polys:
            polys = _fallback_polygons_from_discrete(path2d, transform)
        return _clean_polygons(polys)

    if not polys:
        polys = _fallback_polygons_from_closed(path2d, transform)
        if not polys:
            polys = _fallback_polygons_from_discrete(path2d, transform)
        return _clean_polygons(polys)

    converted = []
    for p in polys:
        try:
            converted.append(_transform_poly_to_xy(p, transform))
        except Exception:
            converted.append(p)
    cleaned = _clean_polygons(converted)
    if not cleaned:
        cleaned = _clean_polygons(_fallback_polygons_from_closed(path2d, transform))
    if not cleaned:
        cleaned = _clean_polygons(_fallback_polygons_from_discrete(path2d, transform))
    return cleaned


def _extract_lines(geom) -> List[LineString]:
    if geom.is_empty:
        return []
    if isinstance(geom, LineString):
        return [geom]
    if isinstance(geom, MultiLineString):
        return list(geom.geoms)
    if isinstance(geom, GeometryCollection):
        lines: List[LineString] = []
        for g in geom.geoms:
            lines.extend(_extract_lines(g))
        return lines
    return []




def _dedupe_segments(segs: List[Segment], ndigits: int = 5) -> List[Segment]:
    """Remove exact/near exact duplicate segments while preserving order."""
    out: List[Segment] = []
    seen = set()
    for s in segs:
        key = tuple(round(float(v), ndigits) for v in s)
        rkey = (key[2], key[3], key[0], key[1])
        # Do not collapse reverse direction for hatch lines; direction matters
        # for side wire feeding.  Only exact duplicates are removed.
        if key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out

def _section_polygons_at_z(mesh: trimesh.Trimesh, z: float, tolerance: float = 1e-6,
                           probe_radius: float = 0.0, probe_count: int = 7):
    """Return robust XY polygons for an STL section near Z.

    v2.8 improvement: a mathematically valid STL can still return an empty
    section exactly at a vertex/edge level or on a near-tangent slice.  For
    EBAM this used to create skipped layers.  We now probe nearby Z levels
    and choose the largest valid section.  This is a geometric robustness
    fallback, not a thermal correction.
    """
    zmin = float(mesh.bounds[0, 2])
    zmax = float(mesh.bounds[1, 2])
    eps = max(tolerance, 1e-5)
    z0 = min(max(float(z), zmin + eps), zmax - eps)

    candidates = [z0]
    if probe_radius > 1e-9 and probe_count > 1:
        # symmetric probing: z, +/- small, +/- medium, +/- max
        fractions = [0.18, 0.32, 0.50, 0.72, 1.00]
        for fr in fractions:
            dz = probe_radius * fr
            candidates.append(min(max(z0 + dz, zmin + eps), zmax - eps))
            candidates.append(min(max(z0 - dz, zmin + eps), zmax - eps))

    best_polys = []
    best_area = -1.0
    seen = set()
    for zz in candidates:
        key = round(float(zz), 8)
        if key in seen:
            continue
        seen.add(key)
        section = mesh.section(plane_origin=[0.0, 0.0, float(zz)], plane_normal=[0.0, 0.0, 1.0])
        polys = _path2d_polygons(section)
        if not polys:
            # v3.1: fully offline fallback independent of trimesh polygonization/rtree.
            polys = _manual_section_polygons_at_z(mesh, float(zz))
        if not polys:
            continue
        try:
            u = unary_union(polys)
            if isinstance(u, Polygon):
                polys = [u]
            elif isinstance(u, MultiPolygon):
                polys = list(u.geoms)
        except Exception:
            pass
        area = sum(float(p.area) for p in polys if p is not None and not p.is_empty)
        if area > best_area:
            best_area = area
            best_polys = polys
    return best_polys


def _clean_polygons(polys: Iterable[Polygon]) -> List[Polygon]:
    out = []
    for p in polys:
        if p is None or p.is_empty:
            continue
        try:
            if not p.is_valid:
                p = p.buffer(0)
        except Exception:
            continue
        if isinstance(p, Polygon) and p.area > 1e-6:
            out.append(p)
        elif isinstance(p, MultiPolygon):
            out.extend([g for g in p.geoms if g.area > 1e-6])
    if not out:
        return []
    try:
        u = unary_union(out)
        if isinstance(u, Polygon):
            return [u]
        if isinstance(u, MultiPolygon):
            return [g for g in u.geoms if g.area > 1e-6]
    except Exception:
        pass
    return out


def _hatch_segments_for_polygons(polys, settings: ProcessSettings, layer_index: int) -> List[Segment]:
    segments: List[Segment] = []
    if not polys:
        return segments

    shift_options = [settings.shift_fraction_a, settings.shift_fraction_b, settings.shift_fraction_c]
    shift = shift_options[layer_index % len(shift_options)] * settings.hatch_spacing if settings.alternate_hatch_shift else 0.0
    direction = settings.direction.upper().strip()
    axis_y = direction.startswith("Y")

    for poly in polys:
        if poly.is_empty:
            continue
        work_poly = poly
        if settings.edge_offset > 0:
            try:
                work_poly = poly.buffer(-settings.edge_offset)
            except Exception:
                work_poly = poly
            if work_poly.is_empty:
                work_poly = poly

        minx, miny, maxx, maxy = work_poly.bounds
        if maxx - minx < 1e-6 or maxy - miny < 1e-6:
            continue

        if axis_y:
            if maxy - miny < settings.min_segment_length:
                continue
            start = minx + settings.hatch_spacing / 2.0 + shift
            while start < minx:
                start += settings.hatch_spacing
            while start - settings.hatch_spacing >= minx:
                start -= settings.hatch_spacing
            x = start
            guard = 0
            while x <= maxx + 1e-9 and guard < 20000:
                guard += 1
                line = LineString([(x, miny - 5 * settings.hatch_spacing - 10), (x, maxy + 5 * settings.hatch_spacing + 10)])
                inter = work_poly.intersection(line)
                for ls in _extract_lines(inter):
                    coords = list(ls.coords)
                    if len(coords) < 2:
                        continue
                    yvals = [c[1] for c in coords]
                    y0, y1 = float(min(yvals)), float(max(yvals))
                    if abs(y1 - y0) < settings.min_segment_length:
                        continue
                    if direction == "Y+":
                        segments.append((float(x), y0, float(x), y1))
                    else:
                        segments.append((float(x), y1, float(x), y0))
                x += settings.hatch_spacing
        else:
            if maxx - minx < settings.min_segment_length:
                continue
            start = miny + settings.hatch_spacing / 2.0 + shift
            while start < miny:
                start += settings.hatch_spacing
            while start - settings.hatch_spacing >= miny:
                start -= settings.hatch_spacing
            y = start
            guard = 0
            while y <= maxy + 1e-9 and guard < 20000:
                guard += 1
                line = LineString([(minx - 5 * settings.hatch_spacing - 10, y), (maxx + 5 * settings.hatch_spacing + 10, y)])
                inter = work_poly.intersection(line)
                for ls in _extract_lines(inter):
                    coords = list(ls.coords)
                    if len(coords) < 2:
                        continue
                    xvals = [c[0] for c in coords]
                    x0, x1 = float(min(xvals)), float(max(xvals))
                    if abs(x1 - x0) < settings.min_segment_length:
                        continue
                    if direction == "X+":
                        segments.append((x0, float(y), x1, float(y)))
                    else:
                        segments.append((x1, float(y), x0, float(y)))
                y += settings.hatch_spacing

    if axis_y:
        segments.sort(key=lambda s: s[0])
    else:
        segments.sort(key=lambda s: s[1])

    if settings.thermal_ordering == "skip_neighbours":
        even = segments[0::2]
        odd = segments[1::2]
        return even + odd[::-1]
    return segments


def _line_ring_to_segments(coords: List[Tuple[float, float]], min_len: float) -> List[Segment]:
    if len(coords) < 2:
        return []
    segs: List[Segment] = []
    for a, b in zip(coords[:-1], coords[1:]):
        x0, y0 = float(a[0]), float(a[1])
        x1, y1 = float(b[0]), float(b[1])
        if math.hypot(x1 - x0, y1 - y0) >= min_len:
            segs.append((x0, y0, x1, y1))
    return segs


def _rotate_closed_coords(coords: List[Tuple[float, float]], direction: str) -> List[Tuple[float, float]]:
    # remove duplicated close point for rotation then close again
    if len(coords) > 1 and math.hypot(coords[0][0]-coords[-1][0], coords[0][1]-coords[-1][1]) < 1e-9:
        base = coords[:-1]
    else:
        base = coords[:]
    if not base:
        return coords
    d = direction.upper()
    if d == "Y-":
        idx = max(range(len(base)), key=lambda i: base[i][1])
    elif d == "Y+":
        idx = min(range(len(base)), key=lambda i: base[i][1])
    elif d == "X-":
        idx = max(range(len(base)), key=lambda i: base[i][0])
    else:
        idx = min(range(len(base)), key=lambda i: base[i][0])
    rot = base[idx:] + base[:idx]
    rot.append(rot[0])
    return rot


def _contour_segments_for_polygons(polys, settings: ProcessSettings, layer_index: int) -> List[Segment]:
    if settings.contour_passes <= 0:
        return []
    segs: List[Segment] = []
    for poly in polys:
        if poly.is_empty:
            continue
        for pidx in range(settings.contour_passes):
            offset = settings.edge_offset + pidx * max(settings.contour_offset_step, 0.01)
            try:
                work = poly.buffer(-offset) if offset > 0 else poly
            except Exception:
                work = poly
            if work.is_empty:
                continue
            geoms = [work] if isinstance(work, Polygon) else list(work.geoms) if isinstance(work, MultiPolygon) else []
            for g in geoms:
                coords = [(float(x), float(y)) for x, y in list(g.exterior.coords)]
                coords = _rotate_closed_coords(coords, settings.direction)
                segs.extend(_line_ring_to_segments(coords, settings.min_segment_length * 0.4))
                for interior in g.interiors:
                    icoords = [(float(x), float(y)) for x, y in list(interior.coords)]
                    icoords = _rotate_closed_coords(icoords, settings.direction)
                    segs.extend(_line_ring_to_segments(icoords, settings.min_segment_length * 0.4))
    return segs


def layer_parameters(z: float, zmax: float, settings: ProcessSettings) -> LayerInfo:
    ratio = 0.0 if zmax <= 1e-9 else min(max(z / zmax, 0.0), 1.0)
    e = settings.target_energy_bottom_j_per_mm + (settings.target_energy_top_j_per_mm - settings.target_energy_bottom_j_per_mm) * ratio
    f = settings.feed_bottom_mm_min + (settings.feed_top_mm_min - settings.feed_bottom_mm_min) * ratio
    current = e * f / (60.0 * settings.voltage_kv)
    current = max(settings.current_min_ma, min(settings.current_max_ma, current))
    travel = f / 60.0
    area = settings.wire_area_mm2()
    # Important v3.3 change: wire_max_mm_s is now a control/warning threshold,
    # not a hard clamp. If the calculated deposition requires 18 mm/s, the G-code
    # will show 18 mm/s and the audit/UI will warn only if it exceeds the user-set
    # reference limit. This keeps the calculation physically transparent.
    wire = settings.layer_height * travel * settings.hatch_spacing / max(area * settings.deposition_efficiency, 1e-9)
    wire = max(0.0, wire)
    qmetal = area * wire
    p = settings.voltage_kv * current
    e_vol = p / qmetal if qmetal > 0 else float("inf")
    pause = settings.layer_pause_bottom_s + (settings.layer_pause_top_s - settings.layer_pause_bottom_s) * ratio
    return LayerInfo(index=0, z=float(z), z_next=float(z + settings.layer_height), ratio=float(ratio),
                     current_ma=float(current), feed_mm_min=float(f), travel_speed_mm_s=float(travel),
                     wire_mm_s=float(wire), energy_j_mm=float(e), energy_j_mm3=float(e_vol),
                     layer_pause_s=float(pause))


def _fmt(v: float, nd: int = 3) -> str:
    return f"{v:.{nd}f}"


def _gcode_header(settings: ProcessSettings, stats: Dict[str, float]) -> List[str]:
    return [
        f"(Generated by EBAM G-code Studio v4.2)",
        f"(Machine: {settings.machine_name})",
        f"(Units: mm, absolute coordinates)",
        f"(Model size X={stats['size_x']:.3f} Y={stats['size_y']:.3f} Z={stats['size_z']:.3f}; source={stats.get('source_type','unknown')})",
        f"(WARNING: calculated process only; verify with dry run and short test)",
        "G21 (mm)",
        "G90 (absolute XYZ)",
        "G94 (feed per minute)",
        f"G64 P{_fmt(settings.g64_tolerance_mm,3)}",
        "M429 (identity kinematics, if available)",
        "M68 E0 Q0.000 (beam current OFF)",
        "M68 E2 Q0.000 (wire feed OFF)",
        f"M68 E1 Q{_fmt(settings.focus_ma,3)} (focus)",
        f"G0 Z{_fmt(settings.z_hop_mm,3)}",
    ]


def _gcode_footer(settings: ProcessSettings) -> List[str]:
    return [
        "(--- FINISH ---)",
        "M68 E2 Q0.000",
        "M68 E0 Q0.000",
        f"G0 Z{_fmt(settings.safe_z_final_mm,3)}",
        "M30",
    ]


def _relative_w_move(delta: float, feed: float) -> List[str]:
    return [
        "G91 (relative for W)",
        f"G1 W{_fmt(delta,3)} F{_fmt(feed,1)}",
        "G90 (absolute XYZ)",
    ]


def _beam_wire_segment_gcode(seg: Segment, layer: LayerInfo, settings: ProcessSettings, edge_factor: float = 1.0,
                             segment_kind: str = "hatch") -> List[str]:
    x0, y0, x1, y1 = seg
    dx = x1 - x0
    dy = y1 - y0
    length = math.hypot(dx, dy)
    if length < settings.min_segment_length * 0.35:
        return []
    ux = dx / length
    uy = dy / length

    max_each = max(length * 0.22, 0.05)
    lead = min(settings.lead_in_beam_mm, max_each)
    soft_s = min(settings.soft_start_mm, max_each)
    soft_f = min(settings.soft_finish_mm, max_each)
    tail = min(settings.tail_beam_mm, max_each)
    if lead + soft_s + soft_f + tail > length * 0.80:
        scale = (length * 0.80) / max(lead + soft_s + soft_f + tail, 1e-9)
        lead *= scale; soft_s *= scale; soft_f *= scale; tail *= scale

    def pt_at(dist: float) -> Tuple[float, float]:
        return (x0 + ux * dist, y0 + uy * dist)

    p_lead = pt_at(lead)
    p_soft = pt_at(lead + soft_s)
    p_soft_fin = pt_at(max(lead + soft_s, length - tail - soft_f))
    p_tail = pt_at(max(lead + soft_s, length - tail))

    wire_main = layer.wire_mm_s * edge_factor
    feed = layer.feed_mm_min
    if segment_kind == "contour":
        wire_main *= settings.contour_wire_factor
        feed *= settings.contour_feed_factor
    wire_soft = wire_main * settings.soft_wire_factor

    lines: List[str] = []
    z_safe = layer.z + settings.z_hop_mm
    if settings.include_comments:
        lines.append(f"({segment_kind.upper()} L{layer.index} X{_fmt(x0,3)} Y{_fmt(y0,3)} -> X{_fmt(x1,3)} Y{_fmt(y1,3)})")
    lines.append(f"G0 Z{_fmt(z_safe,3)}")
    lines.append(f"G0 X{_fmt(x0,3)} Y{_fmt(y0,3)}")
    lines.append(f"G1 Z{_fmt(layer.z,3)} F{_fmt(settings.work_z_feed_mm_min,1)}")
    lines.append(f"M68 E0 Q{_fmt(layer.current_ma,3)}")
    if settings.beam_preheat_s > 0:
        lines.append(f"G4 P{_fmt(settings.beam_preheat_s,3)}")
    if lead > 1e-6:
        lines.append(f"G1 X{_fmt(p_lead[0],3)} Y{_fmt(p_lead[1],3)} F{_fmt(feed,1)}")

    if settings.use_w_retract:
        lines.extend(_relative_w_move(settings.w_retract_mm, settings.w_retract_feed_mm_min))

    lines.append(f"M68 E2 Q{_fmt(wire_soft,3)}")
    if settings.wire_settle_s > 0:
        lines.append(f"G4 P{_fmt(settings.wire_settle_s,3)}")
    if math.hypot(p_soft[0]-p_lead[0], p_soft[1]-p_lead[1]) > 1e-6:
        lines.append(f"G1 X{_fmt(p_soft[0],3)} Y{_fmt(p_soft[1],3)} F{_fmt(feed,1)}")
    lines.append(f"M68 E2 Q{_fmt(wire_main,3)}")
    if math.hypot(p_soft_fin[0]-p_soft[0], p_soft_fin[1]-p_soft[1]) > 1e-6:
        lines.append(f"G1 X{_fmt(p_soft_fin[0],3)} Y{_fmt(p_soft_fin[1],3)} F{_fmt(feed,1)}")
    lines.append(f"M68 E2 Q{_fmt(wire_soft,3)}")
    if math.hypot(p_tail[0]-p_soft_fin[0], p_tail[1]-p_soft_fin[1]) > 1e-6:
        lines.append(f"G1 X{_fmt(p_tail[0],3)} Y{_fmt(p_tail[1],3)} F{_fmt(feed,1)}")
    lines.append("M68 E2 Q0.000")
    if math.hypot(x1-p_tail[0], y1-p_tail[1]) > 1e-6:
        lines.append(f"G1 X{_fmt(x1,3)} Y{_fmt(y1,3)} F{_fmt(feed,1)}")
    lines.append("M68 E0 Q0.000")
    if settings.beam_off_pause_s > 0:
        lines.append(f"G4 P{_fmt(settings.beam_off_pause_s,3)}")

    if settings.use_w_retract:
        lines.extend(_relative_w_move(-settings.w_retract_mm, settings.w_retract_feed_mm_min))
    elif settings.use_m68_speed_retract:
        lines.append(f"M68 E2 Q-{_fmt(settings.speed_retract_mm_s,3)}")
        lines.append(f"G4 P{_fmt(settings.speed_retract_time_s,3)}")
        lines.append("M68 E2 Q0.000")

    lines.append(f"G0 Z{_fmt(z_safe,3)}")
    return lines


def _edge_compensation_factors(segs: List[Segment], settings: ProcessSettings, layer: LayerInfo) -> Dict[Tuple[float, float], float]:
    axis_y = settings.direction.upper().startswith("Y")
    key_func = (lambda s: round(s[0], 6)) if axis_y else (lambda s: round(s[1], 6))
    vals = sorted({key_func(s) for s in segs})
    edge_vals = {vals[0], vals[-1]} if vals else set()
    near_vals = set()
    if len(vals) >= 4:
        near_vals = {vals[1], vals[-2]}
    edge_factor = settings.edge_wire_factor_bottom + (settings.edge_wire_factor_top - settings.edge_wire_factor_bottom) * layer.ratio
    near_factor = settings.near_edge_wire_factor_bottom + (settings.near_edge_wire_factor_top - settings.near_edge_wire_factor_bottom) * layer.ratio
    factors: Dict[Tuple[float, float], float] = {}
    for s in segs:
        v = key_func(s)
        f = 1.0
        if v in edge_vals:
            f = edge_factor
        elif v in near_vals:
            f = near_factor
        factors[(round(s[0], 6), round(s[1], 6))] = f
    return factors


def _generate_with_polygon_provider(provider: Callable[[float], List[Polygon]], height: float, stats: Dict[str, Any], settings: ProcessSettings, progress_callback: Optional[Callable[[int, int, str], None]] = None) -> GenerationResult:
    if height <= 0:
        raise ValueError("Model has zero Z height")
    if settings.layer_height <= 0 or settings.hatch_spacing <= 0:
        raise ValueError("layer_height and hatch_spacing must be positive")

    n_layers_full = int(math.ceil(height / settings.layer_height))
    if settings.max_layers_to_generate and settings.max_layers_to_generate > 0:
        n_layers = max(1, min(int(settings.max_layers_to_generate), n_layers_full))
    else:
        n_layers = n_layers_full
    z_values = [min(i * settings.layer_height, height) for i in range(n_layers)]
    z_sections = [min(z + settings.layer_height * 0.5, height - 1e-4) for z in z_values]
    if progress_callback:
        try:
            progress_callback(0, n_layers, "start")
        except Exception:
            pass

    lines = _gcode_header(settings, stats)
    if settings.use_w_retract and settings.w_retract_mm > 0:
        lines.append("(Initial W retract calibration)")
        lines.append("G10 L20 P0 W0")
        lines.extend(_relative_w_move(-settings.w_retract_mm, settings.w_retract_feed_mm_min))

    layer_infos: List[LayerInfo] = []
    total_active_len = 0.0
    total_contour_len = 0.0
    total_segments = 0
    total_contours = 0
    max_segments_layer = 0
    warning_messages: List[str] = []

    for idx, (z, zsec) in enumerate(zip(z_values, z_sections), start=1):
        if progress_callback and ((idx == 1) or (idx == n_layers) or (idx % max(1, int(settings.progress_update_every_layers)) == 0)):
            try:
                progress_callback(idx, n_layers, "slicing/gcode")
            except Exception:
                pass
        layer = layer_parameters(z, height, settings)
        layer.index = idx
        polys = provider(zsec)
        if not polys:
            warning_messages.append(f"Layer {idx}: no section/polygon at Z={zsec:.3f}; skipped")
            continue
        segs = _dedupe_segments(_hatch_segments_for_polygons(polys, settings, idx))
        conts: List[Segment] = []
        if settings.contour_passes > 0 and settings.contour_every_n_layers > 0 and (idx - 1) % settings.contour_every_n_layers == 0:
            conts = _dedupe_segments(_contour_segments_for_polygons(polys, settings, idx))

        # v2.7: adaptive recovery for thin STL layers.
        # A cup/bowl often has upper ring-like sections that become thinner than
        # the normal hatch spacing and edge offset. Older versions skipped such
        # layers. Here we retry with a smaller edge offset/spacing, and if hatch
        # still cannot be created we force a contour-only toolpath for that layer.
        if settings.adaptive_thin_wall and not segs:
            thin_settings = replace(
                settings,
                edge_offset=max(0.0, min(settings.edge_offset * settings.thin_wall_edge_offset_factor, settings.edge_offset, 0.35)),
                hatch_spacing=max(0.35, min(settings.hatch_spacing * settings.thin_wall_hatch_spacing_factor, settings.hatch_spacing)),
                min_segment_length=max(0.25, min(settings.thin_wall_min_segment_length, settings.min_segment_length)),
            )
            segs_retry = _dedupe_segments(_hatch_segments_for_polygons(polys, thin_settings, idx))
            if segs_retry:
                segs = segs_retry
                if settings.adaptive_wire_correction and settings.hatch_spacing > 1e-9:
                    wire_factor = max(0.25, min(1.0, thin_settings.hatch_spacing / settings.hatch_spacing))
                    layer = replace(layer, wire_mm_s=max(0.0, layer.wire_mm_s * wire_factor))
                warning_messages.append(f"Layer {idx}: adaptive thin-wall hatch used; wire corrected to {layer.wire_mm_s:.3f} mm/s")

        if settings.adaptive_thin_wall and settings.force_contour_on_empty_layers and not segs and not conts:
            contour_settings = replace(
                settings,
                contour_passes=max(1, settings.contour_passes),
                edge_offset=max(0.0, min(settings.edge_offset * settings.thin_wall_edge_offset_factor, settings.edge_offset, 0.35)),
                min_segment_length=max(0.25, min(settings.thin_wall_min_segment_length, settings.min_segment_length)),
            )
            conts_retry = _dedupe_segments(_contour_segments_for_polygons(polys, contour_settings, idx))
            if conts_retry:
                conts = conts_retry
                layer = replace(layer, wire_mm_s=max(0.0, layer.wire_mm_s * settings.thin_wall_wire_factor))
                warning_messages.append(f"Layer {idx}: contour-only thin-wall fallback used; wire corrected to {layer.wire_mm_s:.3f} mm/s")

        layer.segments_count = len(segs)
        layer.contour_segments_count = len(conts)
        max_segments_layer = max(max_segments_layer, len(segs) + len(conts))
        if not segs and not conts:
            warning_messages.append(f"Layer {idx}: no toolpath segments; shape may be too thin for spacing/offset")
            continue

        lines.append(f"(--- LAYER {idx}/{n_layers} Z={_fmt(layer.z,3)} I={_fmt(layer.current_ma,3)} F={_fmt(layer.feed_mm_min,1)}mm/min WIRE={_fmt(layer.wire_mm_s,3)}mm/s HATCH={len(segs)} CONTOUR={len(conts)} ---)")
        path_len = 0.0
        contour_len = 0.0
        factors = _edge_compensation_factors(segs, settings, layer) if segs else {}

        def emit_hatch():
            nonlocal path_len
            for seg in segs:
                factor = factors.get((round(seg[0], 6), round(seg[1], 6)), 1.0)
                path_len += math.hypot(seg[2]-seg[0], seg[3]-seg[1])
                lines.extend(_beam_wire_segment_gcode(seg, layer, settings, factor, "hatch"))

        def emit_contour():
            nonlocal contour_len
            for seg in conts:
                contour_len += math.hypot(seg[2]-seg[0], seg[3]-seg[1])
                lines.extend(_beam_wire_segment_gcode(seg, layer, settings, 1.0, "contour"))

        if settings.contour_first:
            emit_contour(); emit_hatch()
        else:
            emit_hatch(); emit_contour()

        if layer.layer_pause_s > 0:
            lines.append(f"G4 P{_fmt(layer.layer_pause_s,3)} (layer thermal stabilization)")
        layer.path_length_mm = path_len
        layer.contour_length_mm = contour_len
        total_active_len += path_len + contour_len
        total_contour_len += contour_len
        total_segments += len(segs)
        total_contours += len(conts)
        layer_infos.append(layer)

    if not layer_infos:
        raise RuntimeError("No toolpath layers were generated. Check STL orientation, edge offset, hatch spacing, adaptive thin-wall settings, and offline STL fallback. If this is a diagnostic run only, enable XY projection fallback.")
    layer_fraction = len(layer_infos) / max(n_layers, 1)
    if layer_fraction < settings.minimum_generated_layer_fraction:
        warning_messages.append(f"Only {len(layer_infos)}/{n_layers} layers generated ({layer_fraction*100:.1f}%). Geometry may be too thin or STL slicing still unstable.")

    footer_settings = replace(settings, safe_z_final_mm=max(settings.safe_z_final_mm, height + settings.z_hop_mm + 5.0))
    lines.extend(_gcode_footer(footer_settings))
    gcode = "\n".join(lines) + "\n"
    audit = audit_gcode(gcode, settings)

    stats.update({
        "app_version": "v4.2",
        "layers_total": len(layer_infos),
        "layers_requested": n_layers,
        "layers_full_model": n_layers_full,
        "is_test_truncated": bool(n_layers < n_layers_full),
        "layer_fraction": len(layer_infos) / max(n_layers, 1),
        "segments_total": total_segments,
        "contour_segments_total": total_contours,
        "contour_path_length_mm": total_contour_len,
        "max_segments_per_layer": max_segments_layer,
        "active_path_length_mm": total_active_len,
        "active_path_length_m": total_active_len / 1000.0,
        "estimated_active_time_s": sum(((li.path_length_mm / max(li.travel_speed_mm_s, 1e-9)) + (li.contour_length_mm / max(li.travel_speed_mm_s * max(settings.contour_feed_factor, 1e-9), 1e-9))) for li in layer_infos),
        "estimated_wire_length_mm": sum(((li.path_length_mm / max(li.travel_speed_mm_s,1e-9)) * li.wire_mm_s) + ((li.contour_length_mm / max(li.travel_speed_mm_s * max(settings.contour_feed_factor, 1e-9),1e-9)) * li.wire_mm_s * settings.contour_wire_factor) for li in layer_infos),
        "wire_min_calculated_mm_s": min((li.wire_mm_s for li in layer_infos), default=0.0),
        "wire_max_calculated_mm_s": max((li.wire_mm_s for li in layer_infos), default=0.0),
        "feed_min_mm_min": min((li.feed_mm_min for li in layer_infos), default=0.0),
        "feed_max_mm_min": max((li.feed_mm_min for li in layer_infos), default=0.0),
        "process_wire_warning_limit_mm_s": settings.wire_max_mm_s,
        "wire_above_control_limit": any(li.wire_mm_s > settings.wire_max_mm_s for li in layer_infos),
        "current_limit_ma": settings.current_max_ma,
        "current_required_max_ma": max((li.energy_j_mm * li.feed_mm_min / max(60.0 * settings.voltage_kv, 1e-9) for li in layer_infos), default=0.0),
        "current_clipped_by_limit": any((li.energy_j_mm * li.feed_mm_min / max(60.0 * settings.voltage_kv, 1e-9)) > settings.current_max_ma + 1e-9 for li in layer_infos),
        "gcode_lines": len(lines),
        "gcode_size_mb": len(gcode.encode("utf-8")) / (1024.0 * 1024.0),
    })
    stats["estimated_active_time_h"] = stats["estimated_active_time_s"] / 3600.0
    segment_count_for_timing = max(int(stats.get("segments_total", 0)) + int(stats.get("contour_segments_total", 0)), 0)
    layer_pause_time_s = sum(li.layer_pause_s for li in layer_infos)
    per_segment_delay_s = settings.beam_preheat_s + settings.wire_settle_s + settings.beam_off_pause_s
    if settings.use_w_retract and settings.w_retract_mm > 0 and settings.w_retract_feed_mm_min > 0:
        per_segment_delay_s += 2.0 * settings.w_retract_mm / (settings.w_retract_feed_mm_min / 60.0)
    elif settings.use_m68_speed_retract:
        per_segment_delay_s += settings.speed_retract_time_s
    service_factor = 1.15  # acceleration, Z hops, controller latency, operator margin
    stats["estimated_pause_time_s"] = layer_pause_time_s
    stats["estimated_aux_time_s"] = segment_count_for_timing * per_segment_delay_s
    stats["estimated_total_time_s"] = (stats["estimated_active_time_s"] + stats["estimated_pause_time_s"] + stats["estimated_aux_time_s"]) * service_factor
    stats["estimated_total_time_h"] = stats["estimated_total_time_s"] / 3600.0
    if getattr(settings, "target_total_time_s", 0.0) and settings.target_total_time_s > 0:
        stats["target_total_time_s"] = float(settings.target_total_time_s)
        stats["target_total_time_h"] = float(settings.target_total_time_s) / 3600.0
        stats["target_time_mode"] = getattr(settings, "target_time_mode", "unknown")
        stats["target_time_error_s"] = float(stats["estimated_total_time_s"]) - float(settings.target_total_time_s)
        stats["target_time_error_pct"] = 100.0 * stats["target_time_error_s"] / max(float(settings.target_total_time_s), 1e-9)
        stats["target_time_within_15pct"] = abs(stats["target_time_error_pct"]) <= 15.0
    else:
        stats["target_total_time_s"] = 0.0
        stats["target_time_mode"] = "off"
    stats["estimated_wire_length_m"] = stats["estimated_wire_length_mm"] / 1000.0
    volume_wire_mm3 = stats["estimated_wire_length_mm"] * settings.wire_area_mm2()
    stats["estimated_wire_mass_kg"] = volume_wire_mm3 / 1000.0 * settings.density_g_cm3 / 1000.0

    layer_csv = layer_table_csv(layer_infos)
    audit_text = audit_report(settings, stats, audit, warning_messages, layer_infos)
    if n_layers < n_layers_full:
        audit_text += f"\n\nTEST / TRUNCATED FILE:\n  Generated first {n_layers} of {n_layers_full} model layers only. Do not use as full-part program.\n"
    if progress_callback:
        try:
            progress_callback(n_layers, n_layers, "done")
        except Exception:
            pass
    return GenerationResult(gcode=gcode, layer_csv=layer_csv, audit_text=audit_text, stats=stats)



def _xy_projection_polygons_from_mesh(mesh: trimesh.Trimesh) -> List[Polygon]:
    """Last-resort 2.5D XY projection of mesh faces.

    Used only when true layer slicing fails entirely. For complex hollow STL this
    is not as geometrically accurate as slicing, so generated audit carries a
    warning. It is still better than producing an empty G-code file silently.
    """
    try:
        tris = np.asarray(mesh.vertices, dtype=float)[np.asarray(mesh.faces, dtype=np.int64)]
    except Exception:
        return []
    polys = []
    for t in tris:
        pts = [(float(t[0,0]), float(t[0,1])), (float(t[1,0]), float(t[1,1])), (float(t[2,0]), float(t[2,1]))]
        try:
            p = Polygon(pts)
            if p.is_valid and p.area > 1e-6:
                polys.append(p)
        except Exception:
            pass
    if not polys:
        return []
    try:
        u = unary_union(polys)
        if isinstance(u, Polygon):
            return [u]
        if isinstance(u, MultiPolygon):
            return [g for g in u.geoms if g.area > 1e-6]
    except Exception:
        pass
    return _clean_polygons(polys)

def generate_from_mesh(mesh: trimesh.Trimesh, settings: Optional[ProcessSettings] = None, progress_callback: Optional[Callable[[int, int, str], None]] = None) -> GenerationResult:
    if settings is None:
        settings = ProcessSettings()
    mesh_n = normalize_mesh(mesh, settings)
    stats = mesh_summary(mesh_n)
    height = stats["size_z"]
    probe = settings.layer_height * settings.section_probe_fraction if settings.adaptive_section_probe else 0.0

    try:
        return _generate_with_polygon_provider(lambda z: _section_polygons_at_z(mesh_n, z, probe_radius=probe), height, stats, settings, progress_callback=progress_callback)
    except RuntimeError as exc:
        # v3.1 last-resort protection against offline STL polygonization failures:
        # do not return a 24-line empty file; either generate a conservative
        # 2.5D projection fallback or raise a clear error.
        msg = str(exc)
        if (not settings.projection_fallback_if_empty) or ("No toolpath layers" not in msg):
            raise
        proj_polys = _xy_projection_polygons_from_mesh(mesh_n)
        if not proj_polys:
            raise
        fallback_settings = replace(
            settings,
            contour_passes=max(1, settings.contour_passes),
            adaptive_thin_wall=True,
            force_contour_on_empty_layers=True,
            edge_offset=max(0.0, min(settings.edge_offset, 0.35)),
            min_segment_length=max(0.25, min(settings.min_segment_length, 1.0)),
        )
        stats2 = polygon_summary(proj_polys, height)
        stats2.update({
            "source_type": "STL XY projection fallback",
            "projection_fallback_used": True,
            "projection_fallback_warning": "True STL slicing failed; 2.5D XY projection was used as a conservative fallback. Verify geometry carefully before real EBAM run.",
        })
        result = _generate_with_polygon_provider(lambda z: proj_polys, height, stats2, fallback_settings, progress_callback=progress_callback)
        result.audit_text += "\n\nCRITICAL WARNING:\n  STL slicing failed and 2.5D XY projection fallback was used.\n  This may overfill hollow or sloped geometry. Use only after visual verification and dry run.\n"
        result.stats["projection_fallback_used"] = True
        return result

def generate_from_polygons_2d(polys: List[Polygon], height: float, settings: Optional[ProcessSettings] = None, progress_callback: Optional[Callable[[int, int, str], None]] = None) -> GenerationResult:
    if settings is None:
        settings = ProcessSettings()
    clean = _clean_polygons(polys)
    if not clean:
        raise ValueError("No valid polygons")
    # Normalize XY to non-negative if requested by center_xy=False
    if not settings.center_xy:
        u = unary_union(clean)
        minx, miny, _, _ = u.bounds
        if abs(minx) > 1e-9 or abs(miny) > 1e-9:
            from shapely.affinity import translate
            clean = [translate(p, xoff=-minx, yoff=-miny) for p in clean]
    elif settings.center_xy:
        u = unary_union(clean)
        minx, miny, maxx, maxy = u.bounds
        from shapely.affinity import translate
        clean = [translate(p, xoff=-(minx+maxx)/2.0, yoff=-(miny+maxy)/2.0) for p in clean]
    if abs(float(getattr(settings, "output_offset_x_mm", 0.0))) > 1e-12 or abs(float(getattr(settings, "output_offset_y_mm", 0.0))) > 1e-12:
        from shapely.affinity import translate
        clean = [translate(p, xoff=float(getattr(settings, "output_offset_x_mm", 0.0)), yoff=float(getattr(settings, "output_offset_y_mm", 0.0))) for p in clean]
    stats = polygon_summary(clean, height)
    return _generate_with_polygon_provider(lambda z: clean, height, stats, settings, progress_callback=progress_callback)


def layer_table_csv(layer_infos: List[LayerInfo]) -> str:
    header = "layer,z,current_ma,travel_mm_min,wire_mm_s,energy_j_mm,energy_j_mm3,pause_s,hatch_segments,contour_segments,hatch_length_mm,contour_length_mm"
    rows = [header]
    for li in layer_infos:
        rows.append(f"{li.index},{li.z:.3f},{li.current_ma:.3f},{li.feed_mm_min:.1f},{li.wire_mm_s:.3f},{li.energy_j_mm:.2f},{li.energy_j_mm3:.2f},{li.layer_pause_s:.3f},{li.segments_count},{li.contour_segments_count},{li.path_length_mm:.3f},{li.contour_length_mm:.3f}")
    return "\n".join(rows) + "\n"


def audit_gcode(gcode: str, settings: ProcessSettings) -> AuditResult:
    messages: List[str] = []
    ok = True
    beam_on = False
    wire_on = False
    g0_active = 0
    active_x_transition = 0
    active_xy_lines = 0
    m0_count = 0
    cycle_count = 0
    last_x = None
    last_y = None
    last_z = None
    max_i = 0.0
    max_wire = 0.0
    w_pos = 0.0
    w_move_count = 0
    w_move_while_beam_on = 0
    g91_count = 0
    g90_count = 0
    relative_mode = False
    min_x = min_y = min_z = float("inf")
    max_x = max_y = max_z = float("-inf")

    for ln, raw in enumerate(gcode.splitlines(), start=1):
        line = raw.split("(")[0].strip()
        if not line:
            continue
        up = line.upper()
        if up.startswith("G91"):
            relative_mode = True
            g91_count += 1
        if up.startswith("G90"):
            relative_mode = False
            g90_count += 1
        if up.startswith("M0") or " M0" in up:
            m0_count += 1
        if "WHILE" in up or "O<" in up or "CALL" in up or "SUB" in up:
            if not up.startswith("M429"):
                cycle_count += 1
        if up.startswith("M68") and "E0" in up and "Q" in up:
            try:
                q = float(up.split("Q",1)[1].split()[0])
                beam_on = abs(q) > 1e-6
                max_i = max(max_i, abs(q))
            except Exception:
                pass
        if up.startswith("M68") and "E2" in up and "Q" in up:
            try:
                q = float(up.split("Q",1)[1].split()[0])
                wire_on = abs(q) > 1e-6
                max_wire = max(max_wire, abs(q))
            except Exception:
                pass
        motion = up.startswith("G0") or up.startswith("G1") or up.startswith("G00") or up.startswith("G01")
        if motion:
            x = last_x; y = last_y; z = last_z
            parts = up.replace("G00","G0").replace("G01","G1").split()
            w_delta = None
            for p in parts:
                try:
                    if p.startswith("X"): x = float(p[1:])
                    elif p.startswith("Y"): y = float(p[1:])
                    elif p.startswith("Z"): z = float(p[1:])
                    elif p.startswith("W"): w_delta = float(p[1:])
                except ValueError:
                    pass
            if w_delta is not None:
                w_move_count += 1
                if beam_on:
                    w_move_while_beam_on += 1
                # In this generator W moves are intended in G91 relative mode.
                # If a user edits the G-code and makes W absolute, the final
                # value will reveal it in the audit.
                w_pos = w_pos + w_delta if relative_mode else w_delta
            if x is not None:
                min_x = min(min_x, x); max_x = max(max_x, x)
            if y is not None:
                min_y = min(min_y, y); max_y = max(max_y, y)
            if z is not None:
                min_z = min(min_z, z); max_z = max(max_z, z)
            is_g0 = parts[0] in ["G0", "G00"]
            if is_g0 and (beam_on or wire_on):
                g0_active += 1
                ok = False
            if (not is_g0) and (beam_on or wire_on):
                dx = 0.0 if last_x is None or x is None else abs(x-last_x)
                dy = 0.0 if last_y is None or y is None else abs(y-last_y)
                if dx > 1e-6:
                    active_x_transition += 1
                if dx > 1e-6 and dy > 1e-6:
                    active_xy_lines += 1
            last_x, last_y, last_z = x, y, z

    if g0_active:
        messages.append(f"DANGER: {g0_active} rapid G0 moves with beam/wire active")
    if active_x_transition and settings.contour_passes <= 0 and settings.direction.upper().startswith("Y"):
        messages.append(f"WARNING: {active_x_transition} active X motions detected in Y-hatch mode")
    elif active_x_transition:
        messages.append(f"NOTE: {active_x_transition} active X motions detected; expected for contour or X-hatch modes")
    if m0_count:
        messages.append(f"WARNING: M0 count = {m0_count}")
    if cycle_count:
        messages.append(f"WARNING: possible cycles/subprogram calls = {cycle_count}")
    if w_move_count and abs(w_pos + settings.w_retract_mm) > max(0.05, settings.w_retract_mm * 0.25):
        messages.append(f"WARNING: final W estimate is {w_pos:.3f} mm; expected about {-settings.w_retract_mm:.3f} mm if using initial retract")
    if w_move_while_beam_on:
        messages.append(f"NOTE: {w_move_while_beam_on} W moves while beam is ON; this is expected for W recover before wire feed, but verify dry")
    if relative_mode:
        messages.append(f"WARNING: program ends in G91 relative mode; check G90 recovery after W moves")
    if not messages:
        messages.append("No obvious dangerous G0/active transitions found")
    stats = {
        "g0_active": g0_active,
        "active_x_transition": active_x_transition,
        "active_xy_lines": active_xy_lines,
        "m0_count": m0_count,
        "cycle_count": cycle_count,
        "max_current_ma": max_i,
        "max_wire_mm_s": max_wire,
        "w_move_count": w_move_count,
        "w_final_estimate_mm": w_pos,
        "w_moves_while_beam_on": w_move_while_beam_on,
        "g91_count": g91_count,
        "g90_count": g90_count,
        "x_min": None if min_x == float("inf") else min_x,
        "x_max": None if max_x == float("-inf") else max_x,
        "y_min": None if min_y == float("inf") else min_y,
        "y_max": None if max_y == float("-inf") else max_y,
        "z_min": None if min_z == float("inf") else min_z,
        "z_max": None if max_z == float("-inf") else max_z,
    }
    return AuditResult(ok=ok, messages=messages, stats=stats)


def audit_report(settings: ProcessSettings, stats: Dict[str, Any], audit: AuditResult, warnings: List[str], layers: List[LayerInfo]) -> str:
    lines = []
    lines.append("EBAM G-code Studio v4.2 audit")
    lines.append("============================")
    lines.append("")
    lines.append("Process settings:")
    for k, v in asdict(settings).items():
        lines.append(f"  {k}: {v}")
    lines.append("")
    lines.append("Model / generation stats:")
    for k in sorted(stats):
        lines.append(f"  {k}: {stats[k]}")
    if stats.get("gcode_lines", 0) > settings.max_gcode_lines_warning:
        lines.append(f"  WARNING_LARGE_GCODE_LINES: {stats.get('gcode_lines')} lines; LinuxCNC preview/loading can be slow")
    if stats.get("gcode_size_mb", 0.0) > settings.max_gcode_size_mb_warning:
        lines.append(f"  WARNING_LARGE_GCODE_SIZE_MB: {stats.get('gcode_size_mb'):.2f} MB; consider compact output or larger layer/hatch")
    lines.append("")
    lines.append("Static G-code audit:")
    lines.append(f"  OK: {audit.ok}")
    for k, v in audit.stats.items():
        lines.append(f"  {k}: {v}")
    for msg in audit.messages:
        lines.append(f"  - {msg}")
    if warnings:
        lines.append("")
        lines.append("Warnings:")
        for w in warnings[:250]:
            lines.append(f"  - {w}")
        if len(warnings) > 250:
            lines.append(f"  ... {len(warnings)-250} more warnings")
    if layers:
        lines.append("")
        lines.append("Layer range:")
        lines.append(f"  first: Z={layers[0].z:.3f}, I={layers[0].current_ma:.3f}, speed={layers[0].feed_mm_min:.1f} mm/min, wire={layers[0].wire_mm_s:.3f} mm/s")
        lines.append(f"  last:  Z={layers[-1].z:.3f}, I={layers[-1].current_ma:.3f}, speed={layers[-1].feed_mm_min:.1f} mm/min, wire={layers[-1].wire_mm_s:.3f} mm/s")
    if stats.get("target_total_time_s", 0.0):
        lines.append("")
        lines.append("Target-time check:")
        lines.append(f"  target total time: {stats.get('target_total_time_s', 0.0)/3600.0:.2f} h")
        lines.append(f"  estimated total time after real toolpath: {stats.get('estimated_total_time_h', 0.0):.2f} h")
        lines.append(f"  deviation: {stats.get('target_time_error_pct', 0.0):+.1f}%")
        if not stats.get("target_time_within_15pct", True):
            lines.append("  NOTE: target time is not matched closely after real toolpath generation; adjust feed/layer/hatch or use a different target.")

    if stats.get("wire_above_control_limit"):
        lines.append("")
        lines.append("Wire-feed control limit note:")
        lines.append(f"  calculated wire feed reaches {stats.get('wire_max_calculated_mm_s', 0.0):.3f} mm/s; user control limit is {settings.wire_max_mm_s:.3f} mm/s.")
        lines.append("  v4.2 does not clamp this value automatically. If the real feeder allows it, raise the control limit; otherwise reduce Z-step, hatch spacing or feed speed.")
    if stats.get("current_clipped_by_limit"):
        lines.append("")
        lines.append("Beam-current limit note:")
        lines.append(f"  required current reaches {stats.get('current_required_max_ma', 0.0):.3f} mA; selected current limit is {settings.current_max_ma:.3f} mA.")
        lines.append("  G-code current is clipped to the selected limit, so actual J/mm will be lower than requested. Raise the limit only if the real EBAM source, cooling, vacuum and interlocks allow it.")
    lines.append("")
    lines.append("Important engineering notes:")
    lines.append("  1. This generator uses calculated start regimes, not real closed-loop thermal control.")
    lines.append("  2. Always run dry simulation and a short Z10-15 mm test before full build.")
    lines.append("  3. Verify W retract direction and that W does not conflict with M68 E2 wire speed control.")
    lines.append("  4. If top becomes shiny/liquid early, reduce target energy or add cooling pause.")
    lines.append("  5. If wire knocks/stubs, increase energy or reduce wire feed/layer height.")
    lines.append("  6. Contour passes improve shape but may violate ideal side-wire direction on some segments.")
    return "\n".join(lines) + "\n"


def save_result(result: GenerationResult, out_prefix: str | Path) -> Dict[str, Path]:
    p = Path(out_prefix)
    p.parent.mkdir(parents=True, exist_ok=True)
    files = {
        "gcode": p.with_suffix(".ngc"),
        "layers": p.with_name(p.name + "_layers.csv"),
        "audit": p.with_name(p.name + "_audit.txt"),
    }
    files["gcode"].write_text(result.gcode, encoding="utf-8")
    files["layers"].write_text(result.layer_csv, encoding="utf-8")
    files["audit"].write_text(result.audit_text, encoding="utf-8")
    return files


def settings_to_json(settings: ProcessSettings) -> str:
    """User-facing JSON stores movement feed speeds in mm/min.

    This matches LinuxCNC/G-code F words (G94 feed per minute). Wire feed
    remains in mm/s because it is sent through M68 E2 as a process speed.
    The loader still accepts older *_mm_s movement-speed keys for backward
    compatibility and converts them to *_mm_min.
    """
    data = asdict(settings)
    data["speed_unit_note"] = "Movement speeds are mm/min and are written to G-code F directly. Wire feed remains mm/s."
    return json.dumps(data, indent=2, ensure_ascii=False)


def settings_from_dict(d: Dict[str, Any]) -> ProcessSettings:
    base = asdict(ProcessSettings())
    speed_map = {
        "feed_bottom_mm_s": "feed_bottom_mm_min",
        "feed_top_mm_s": "feed_top_mm_min",
        "w_retract_feed_mm_s": "w_retract_feed_mm_min",
        "rapid_feed_z_mm_s": "rapid_feed_z_mm_min",
        "work_z_feed_mm_s": "work_z_feed_mm_min",
    }
    converted = dict(d)
    for src, dst in speed_map.items():
        if src in converted:
            converted[dst] = float(converted[src]) * 60.0
    for k, v in converted.items():
        if k in base:
            base[k] = v
    return ProcessSettings(**base)


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def recommend_settings_from_summary(summary: Dict[str, float], mode: str = "balanced", material_key: str = "stainless_steel_12_wire") -> ProcessSettings:
    m = mode.lower()
    s = ProcessSettings()
    mat = MATERIAL_LIBRARY.get(material_key, MATERIAL_LIBRARY["stainless_steel_12_wire"])
    s.density_g_cm3 = float(mat.get("density_g_cm3", s.density_g_cm3))
    s.wire_diameter_mm = float(mat.get("wire_diameter_mm", s.wire_diameter_mm))
    base_e0 = float(mat.get("energy_bottom_j_mm", s.target_energy_bottom_j_per_mm))
    base_e1 = float(mat.get("energy_top_j_mm", s.target_energy_top_j_per_mm))
    sx = float(summary.get("size_x", 20.0) or 20.0)
    sy = float(summary.get("size_y", 100.0) or 100.0)
    sz = float(summary.get("size_z", 100.0) or 100.0)
    min_xy = max(min(sx, sy), 1.0)
    slender = sz / max(min_xy, 1.0)

    if "quality" in m or "кач" in m:
        s.layer_height = _clamp(sz / 420.0, 0.20, 0.32)
        s.hatch_spacing = _clamp(min_xy / 10.0, 1.4, 2.0)
        s.feed_bottom_mm_min = 610.0
        s.feed_top_mm_min = 670.0
        s.target_energy_bottom_j_per_mm = base_e0 + 2.0
        s.target_energy_top_j_per_mm = base_e1
        s.contour_passes = 1
        s.contour_every_n_layers = 2
    elif "speed" in m or "скор" in m:
        s.layer_height = _clamp(sz / 230.0, 0.35, 0.60)
        s.hatch_spacing = _clamp(min_xy / 8.0, 2.0, 3.0)
        s.feed_bottom_mm_min = 700.0
        s.feed_top_mm_min = 790.0
        s.target_energy_bottom_j_per_mm = base_e0 + 8.0
        s.target_energy_top_j_per_mm = base_e1 + 7.0
        s.contour_passes = 0
    else:
        s.layer_height = _clamp(sz / 330.0, 0.25, 0.42)
        s.hatch_spacing = _clamp(min_xy / 9.0, 1.7, 2.35)
        s.feed_bottom_mm_min = 650.0
        s.feed_top_mm_min = 730.0
        s.target_energy_bottom_j_per_mm = base_e0
        s.target_energy_top_j_per_mm = base_e1
        s.contour_passes = 1
        s.contour_every_n_layers = 3

    if slender > 4.0:
        s.target_energy_top_j_per_mm -= 4.0
        s.edge_wire_factor_top = 0.85
        s.near_edge_wire_factor_top = 0.92
        s.layer_pause_top_s = 0.55
    if min_xy < 8.0:
        s.hatch_spacing = _clamp(min_xy / 4.0, 0.6, s.hatch_spacing)
        s.layer_height = min(s.layer_height, 0.25)
    if sx > 80 or sy > 80:
        s.feed_top_mm_min += 20.0
    s.center_xy = False
    s.z_to_zero = True
    return s


def generate_from_stl_file(stl_path: str | Path, settings: Optional[ProcessSettings] = None) -> GenerationResult:
    mesh = load_mesh_any(stl_path)
    return generate_from_mesh(mesh, settings)


def load_polygons_from_csv(path_or_text: str | Path, delimiter: str = ",") -> List[Polygon]:
    if isinstance(path_or_text, (str, Path)) and Path(str(path_or_text)).exists():
        text = Path(str(path_or_text)).read_text(encoding="utf-8-sig")
    else:
        text = str(path_or_text)
    rows = list(csv.reader(io.StringIO(text), delimiter=delimiter))
    pts: List[Tuple[float, float]] = []
    for row in rows:
        if not row or len(row) < 2:
            continue
        try:
            pts.append((float(row[0]), float(row[1])))
        except Exception:
            # ignore header/non-numeric row
            continue
    if len(pts) < 3:
        raise ValueError("CSV must contain at least 3 numeric X,Y points")
    if math.hypot(pts[0][0]-pts[-1][0], pts[0][1]-pts[-1][1]) > 1e-6:
        pts.append(pts[0])
    p = Polygon(pts)
    return _clean_polygons([p])


def load_polygons_from_dxf(path: str | Path) -> List[Polygon]:
    try:
        import ezdxf  # type: ignore
    except Exception as exc:
        raise RuntimeError("DXF support requires ezdxf. Install requirements.txt") from exc
    doc = ezdxf.readfile(str(path))
    msp = doc.modelspace()
    polys: List[Polygon] = []
    lines: List[LineString] = []
    for e in msp:
        t = e.dxftype().upper()
        try:
            if t == "LWPOLYLINE":
                pts = [(float(p[0]), float(p[1])) for p in e.get_points()]
                if len(pts) >= 3 and (e.closed or math.hypot(pts[0][0]-pts[-1][0], pts[0][1]-pts[-1][1]) < 1e-6):
                    if math.hypot(pts[0][0]-pts[-1][0], pts[0][1]-pts[-1][1]) > 1e-6:
                        pts.append(pts[0])
                    polys.append(Polygon(pts))
                elif len(pts) >= 2:
                    lines.append(LineString(pts))
            elif t == "POLYLINE":
                pts = [(float(v.dxf.location.x), float(v.dxf.location.y)) for v in e.vertices]
                if len(pts) >= 3 and (e.is_closed or math.hypot(pts[0][0]-pts[-1][0], pts[0][1]-pts[-1][1]) < 1e-6):
                    if math.hypot(pts[0][0]-pts[-1][0], pts[0][1]-pts[-1][1]) > 1e-6:
                        pts.append(pts[0])
                    polys.append(Polygon(pts))
                elif len(pts) >= 2:
                    lines.append(LineString(pts))
            elif t == "LINE":
                s = e.dxf.start; en = e.dxf.end
                lines.append(LineString([(float(s.x), float(s.y)), (float(en.x), float(en.y))]))
            elif t == "CIRCLE":
                c = e.dxf.center; r = float(e.dxf.radius)
                polys.append(ShapelyPoint(float(c.x), float(c.y)).buffer(r, resolution=96))
        except Exception:
            continue
    # Try polygonize open linework if no closed polylines found
    if not polys and lines:
        try:
            from shapely.ops import polygonize
            polys = list(polygonize(lines))
        except Exception:
            pass
    return _clean_polygons(polys)
