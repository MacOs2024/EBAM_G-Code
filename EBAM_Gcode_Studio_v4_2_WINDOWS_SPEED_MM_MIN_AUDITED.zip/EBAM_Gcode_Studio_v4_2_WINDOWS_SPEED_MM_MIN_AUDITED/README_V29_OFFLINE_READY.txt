EBAM G-code Studio v2.9 OFFLINE READY
=====================================
Added offline/portable run options:
- run_windows_OFFLINE_EXISTING_VENV.bat: no internet, uses existing .venv
- run_linux_OFFLINE_EXISTING_VENV.sh: no internet, uses existing .venv
- build_windows_portable_exe.bat: build portable EXE folder on Windows
- build_linux_portable_binary.sh: build portable Linux folder on Linux
- download_wheelhouse_windows.bat / install_from_wheelhouse_windows.bat: offline Python package transfer
- desktop_launcher.py: local browser launcher for source/PyInstaller builds
- EBAM_Gcode_Studio.spec: PyInstaller one-folder spec
