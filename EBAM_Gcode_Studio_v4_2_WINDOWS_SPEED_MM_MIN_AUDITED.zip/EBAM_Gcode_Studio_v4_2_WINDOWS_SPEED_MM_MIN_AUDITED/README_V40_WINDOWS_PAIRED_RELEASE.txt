# EBAM G-Code Studio v4.2 — Windows/Linux paired release

Windows-версия идёт в паре с Linux v4.2 Portable Prep.

## Запуск Windows

```bat
run_windows_ROBUST.bat
```

## Что нового в парной версии v4.2

- Windows и Linux архивы выпускаются вместе.
- Linux-архив теперь содержит portable/offline helper scripts.
- Основная логика v3.9 сохранена: скорости движения в интерфейсе в мм/мин, G-code F внутри остаётся в мм/мин для LinuxCNC.

## Безопасность

Перед реальной наплавкой:
preview -> TEST Z10-15 мм -> просмотр G-code/audit -> сухой прогон без луча и проволоки -> проверка W-ретракта -> короткая наплавка -> полный файл.
