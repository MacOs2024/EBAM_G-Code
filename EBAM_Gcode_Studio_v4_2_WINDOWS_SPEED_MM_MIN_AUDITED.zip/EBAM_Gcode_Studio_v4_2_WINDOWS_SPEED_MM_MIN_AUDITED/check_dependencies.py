mods = ['streamlit','numpy','scipy','trimesh','shapely','matplotlib','pandas','ezdxf']
missing=[]
for m in mods:
    try:
        __import__(m)
        print(f'OK: {m}')
    except Exception as e:
        print(f'MISSING/ERROR: {m}: {e}')
        missing.append(m)
if missing:
    raise SystemExit('Missing modules: ' + ', '.join(missing))
print('All dependencies are installed.')
