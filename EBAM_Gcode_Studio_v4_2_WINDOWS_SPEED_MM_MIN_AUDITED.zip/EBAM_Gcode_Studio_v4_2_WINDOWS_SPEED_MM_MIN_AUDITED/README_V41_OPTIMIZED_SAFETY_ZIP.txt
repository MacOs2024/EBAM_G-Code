EBAM G-Code Studio v4.1 OPTIMIZED SAFETY ZIP

Что добавлено:
- Кэширование тяжёлых операций загрузки STL/DXF/CSV и стандартных фигур через Streamlit cache_data.
- Кнопка очистки кэша геометрии в боковой панели.
- Закрытие Matplotlib-фигур после st.pyplot для меньшего расхода памяти при частых preview.
- Единый ZIP результата: G-code, layers.csv, audit.txt, settings.json и README_RESULT_RU.txt.
- Блок статуса допуска: можно готовить TEST / только TEST и сухой прогон / нельзя сразу запускать.
- Streamlit run options в launch-скриптах приведены к формату --section.option=value.
- Shapely unary_union переведён на современный импорт from shapely import unary_union.

Важно:
- В v4.2 скорость движения возвращена в мм/мин; этот файл v4.1 оставлен как история изменений.
- В G-code команда F по-прежнему автоматически пишется в мм/мин для LinuxCNC/G-code.
- Внутренние имена feed_bottom_mm_min/feed_top_mm_min сохранены для совместимости ядра, но добавлены функции преобразования мм/мин <-> мм/с.

Безопасность:
preview -> TEST Z10-15 мм -> просмотр G-code/audit -> сухой прогон без луча и проволоки -> проверка W -> короткая наплавка -> полный файл.
