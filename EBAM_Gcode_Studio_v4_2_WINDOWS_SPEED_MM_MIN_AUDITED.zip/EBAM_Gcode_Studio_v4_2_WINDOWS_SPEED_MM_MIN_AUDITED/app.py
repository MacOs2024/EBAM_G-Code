from __future__ import annotations
import tempfile
import io
import zipfile
from pathlib import Path
import math
from dataclasses import replace

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

from ebam_gcode_studio.core import (
    ProcessSettings, MATERIAL_LIBRARY,
    load_mesh_any, normalize_mesh, mesh_summary,
    generate_from_mesh, generate_from_polygons_2d,
    settings_to_json, settings_from_dict, recommend_settings_from_summary,
    load_polygons_from_csv, load_polygons_from_dxf, create_standard_shape_polygons,
    _section_polygons_at_z, _hatch_segments_for_polygons, _contour_segments_for_polygons,
    polygon_summary
)

st.set_page_config(page_title="EBAM G-Code Studio v4.2", layout="wide")
st.title("EBAM G-Code Studio v4.2")
st.caption("Простой и расширенный режимы • расчёт • preview • G-code")

st.info("Стартовый расчёт для EBAM. Перед полной деталью: preview, TEST Z10–15 мм, сухой прогон, проверка W-ретракта.")

st.markdown(
    """
    <style>
    .block-container {padding-top: 3.2rem; padding-bottom: 2rem;}
    section[data-testid="stSidebar"] .block-container {padding-top: 1rem;}
    h1 {margin-top: 0.2rem; padding-top: 0.2rem;}
    div[data-testid="stMetric"] {background: rgba(128,128,128,0.08); padding: 0.65rem 0.8rem; border-radius: 0.7rem;}
    .ebam-card {border: 1px solid rgba(128,128,128,0.25); border-radius: 0.8rem; padding: 0.85rem 1rem; margin: 0.35rem 0 0.8rem 0;}
    .ebam-small {font-size: 0.92rem; opacity: 0.86;}
    </style>
    """,
    unsafe_allow_html=True,
)

with st.expander("Кратко: как пользоваться", expanded=False):
    st.markdown(
        """
        **Простой режим** — для быстрого расчёта: выбери геометрию, материал и цель `Качество / Баланс / Скорость`.
        Приложение само подбирает Z-шаг, шаг дорожек, скорость, ток, проволоку и паузы.

        **Расширенный режим** — для пусконаладки и экспериментов: открываются все технологические параметры,
        ориентация STL, тонкие fallback-настройки, контуры, W-ретракт, лимиты, целевое время и JSON-профиль.

        **Безопасный порядок:** preview → TEST Z10–15 мм → просмотр G-code/audit → сухой прогон без луча и проволоки → короткая наплавка → полный файл.
        """
    )

# ------------------------- helpers -------------------------
def _tmp_file(uploaded, suffix):
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(uploaded.getbuffer())
        return Path(tmp.name)


@st.cache_data(show_spinner=False)
def _cached_mesh_from_bytes(data: bytes, suffix: str = ".stl"):
    """Load mesh once per uploaded file content.

    Streamlit reruns the script after every widget change; caching avoids re-reading
    the same STL again and again while the operator changes process parameters.
    """
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(data)
        tmp_path = Path(tmp.name)
    try:
        return load_mesh_any(tmp_path)
    finally:
        try:
            tmp_path.unlink(missing_ok=True)
        except Exception:
            pass


@st.cache_data(show_spinner=False)
def _cached_dxf_polygons_from_bytes(data: bytes):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".dxf") as tmp:
        tmp.write(data)
        tmp_path = Path(tmp.name)
    try:
        return load_polygons_from_dxf(tmp_path)
    finally:
        try:
            tmp_path.unlink(missing_ok=True)
        except Exception:
            pass


@st.cache_data(show_spinner=False)
def _cached_csv_polygons_from_text(text: str):
    return load_polygons_from_csv(text)


@st.cache_data(show_spinner=False)
def _cached_standard_shape(shape_name: str, params_items: tuple):
    return create_standard_shape_polygons(shape_name, dict(params_items))


def _feed_mm_min_to_speed_mm_s(feed_mm_min: float) -> float:
    return float(feed_mm_min) / 60.0


def _speed_mm_s_to_feed_mm_min(speed_mm_s: float) -> float:
    return float(speed_mm_s) * 60.0


def _make_result_zip(result, settings_json: str, suffix: str) -> bytes:
    """Pack G-code, layer table, audit and settings into one download."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(f"ebam_generated_v42_{suffix}.ngc", result.gcode)
        zf.writestr(f"ebam_layers_v42_{suffix}.csv", result.layer_csv)
        zf.writestr(f"ebam_audit_v42_{suffix}.txt", result.audit_text)
        zf.writestr(f"ebam_settings_v42_{suffix}.json", settings_json)
        zf.writestr(
            "README_RESULT_RU.txt",
            "EBAM G-Code Studio v4.2\n"
            "Комплект результата: G-code, таблица слоёв, аудит и JSON-настройки.\n"
            "Перед реальной наплавкой: viewer/simulation -> сухой прогон без луча и проволоки -> проверка W -> TEST Z10-15 мм.\n"
        )
    return buf.getvalue()


def _safety_gate_status(src_type: str, summary, settings: ProcessSettings, time_plan,
                        n_layers: int, wire_bottom: float, wire_top: float,
                        current_bottom_need: float, current_top_need: float):
    """Small operator-oriented status block: can we proceed to TEST?"""
    critical = []
    warn = []
    info = []

    if n_layers <= 0 or float(summary.get("size_z", 0.0) or 0.0) <= 0:
        critical.append("Геометрия не даёт положительной высоты Z или числа слоёв.")
    if current_bottom_need > settings.current_max_ma * 1.001 or current_top_need > settings.current_max_ma * 1.001:
        critical.append("Расчётный ток выше заданного лимита E0: в G-code будет клиппинг тока и энергия получится ниже расчётной.")
    if src_type == "STL 3D" and settings.projection_fallback_if_empty:
        warn.append("Включён последний fallback XY-проекции STL: для реальной детали использовать только после диагностики.")
    if max(wire_bottom, wire_top) > settings.wire_max_mm_s:
        warn.append("Расчётная подача проволоки выше вашей контрольной границы. Это не ошибка, но нужен сухой прогон подачи.")
    if settings.layer_height > 0.75:
        warn.append("Z-шаг крупный: выше риск грубой поверхности и нестабильного формирования слоя.")
    if settings.hatch_spacing > 4.0:
        warn.append("Шаг дорожек крупный: возможны борозды и неперекрытие дорожек.")
    if max(settings.feed_bottom_mm_min, settings.feed_top_mm_min) > 1200.0:
        warn.append("Скорость движения выше 1200 мм/мин: выше риск холодной ванны и тыкания проволоки.")
    if time_plan.get("enabled") and time_plan.get("severity") == "bad":
        warn.append("Целевое время сильно расходится с расчётом: режим нужно проверять только коротким TEST.")
    if src_type == "STL 3D" and not summary.get("is_watertight", True):
        warn.append("STL не замкнутый: сечения могут быть неполными.")
    if n_layers > 300:
        info.append("Слоёв много: полный файл может генерироваться долго, сначала лучше TEST.")

    if critical:
        return "bad", "❌ Нельзя сразу запускать", critical + warn + info
    if warn:
        return "warn", "⚠️ Только TEST и сухой прогон", warn + info
    return "ok", "✅ Можно готовить TEST", ["Критичных расчётных ограничений не найдено. Всё равно нужен viewer, audit и сухой прогон."] + info


def _fmt_hm(seconds: float) -> str:
    seconds = max(0.0, float(seconds or 0.0))
    h = int(seconds // 3600)
    m = int(round((seconds - h * 3600) / 60.0))
    if m >= 60:
        h += 1
        m -= 60
    return f"{h} ч {m:02d} мин"


def _estimate_time_before_generation(summary, settings: ProcessSettings):
    """Fast approximate timing before full G-code generation.

    Exact time is known only after building all toolpath segments. This estimate
    uses volume, calculated wire flow and pauses, so it is useful in the summary
    tab before pressing Generate.
    """
    height = max(float(summary.get("size_z", 0.0) or 0.0), 1e-9)
    n_layers = int(math.ceil(height / max(settings.layer_height, 1e-9)))
    area_wire = settings.wire_area_mm2()
    wire_bottom = settings.layer_height * (settings.feed_bottom_mm_min / 60.0) * settings.hatch_spacing / max(area_wire * settings.deposition_efficiency, 1e-9)
    wire_top = settings.layer_height * (settings.feed_top_mm_min / 60.0) * settings.hatch_spacing / max(area_wire * settings.deposition_efficiency, 1e-9)
    avg_wire = max(1e-9, (wire_bottom + wire_top) / 2.0)
    volume = float(summary.get("volume_mm3", float("nan")))
    if not math.isfinite(volume) or volume <= 0:
        # Non-watertight STL: use a conservative fraction of the bounding box.
        volume = float(summary.get("size_x", 0.0)) * float(summary.get("size_y", 0.0)) * height * 0.20
    metal_rate_mm3_s = area_wire * avg_wire * max(settings.deposition_efficiency, 1e-9)
    active_s = volume / max(metal_rate_mm3_s, 1e-9)
    pause_s = n_layers * (settings.layer_pause_bottom_s + settings.layer_pause_top_s) / 2.0
    aux_s = n_layers * 1.5  # rough Z-hop/retract/controller overhead before full path is known
    total_s = (active_s + pause_s + aux_s) * 1.15
    return {
        "n_layers": n_layers,
        "wire_bottom": wire_bottom,
        "wire_top": wire_top,
        "active_s": active_s,
        "pause_s": pause_s,
        "total_s": total_s,
        "volume_used_mm3": volume,
    }




def _clamp_float(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, float(v)))


def _current_limited_feed_cap(settings: ProcessSettings) -> tuple[float, float]:
    """Maximum feed that still preserves requested J/mm without current clipping."""
    cap0 = settings.current_max_ma * 60.0 * settings.voltage_kv / max(settings.target_energy_bottom_j_per_mm, 1e-9)
    cap1 = settings.current_max_ma * 60.0 * settings.voltage_kv / max(settings.target_energy_top_j_per_mm, 1e-9)
    return min(3000.0, cap0), min(3000.0, cap1)



def _fit_settings_to_target_time(summary, base: ProcessSettings, target_s: float, fit_mode: str):
    """Return settings adjusted toward target total time and a human-readable plan.

    v4.2 logic:
    - feed_only: changes only F.
    - feed_layer_hatch: changes F, Z-step and hatch spacing.
    - full_process: may also change thermal pauses and target J/mm within
      conservative boundaries. It NEVER raises current_max_ma automatically:
      current_max_ma is a user-selected equipment/process limit.

    Wire maximum remains a warning threshold, not a hard clamp, because the real
    feeder capability is user-defined by the user/operator.
    """
    target_s = float(target_s or 0.0)
    out = replace(base, target_total_time_s=max(0.0, target_s), target_time_mode=fit_mode)
    base_eta = _estimate_time_before_generation(summary, out)
    plan = {
        "enabled": target_s > 0.0,
        "target_s": target_s,
        "base_total_s": base_eta["total_s"],
        "adjusted_total_s": base_eta["total_s"],
        "possible": True,
        "severity": "ok",
        "messages": [],
        "base_settings": {
            "layer_height": base.layer_height,
            "hatch_spacing": base.hatch_spacing,
            "feed_bottom": base.feed_bottom_mm_min,
            "feed_top": base.feed_top_mm_min,
            "energy_bottom": base.target_energy_bottom_j_per_mm,
            "energy_top": base.target_energy_top_j_per_mm,
            "pause_bottom": base.layer_pause_bottom_s,
            "pause_top": base.layer_pause_top_s,
            "current_max": base.current_max_ma,
        },
        "applied_settings": {},
    }
    if target_s <= 0.0:
        return out, plan

    if target_s < 5 * 60:
        plan["messages"].append("Цель меньше 5 минут: для EBAM это почти всегда только диагностический фрагмент, а не полноценная деталь.")

    # Allowed technological range for automatic fitting. These are not hard machine limits,
    # but reasonable software guard rails so the app does not silently create absurd regimes.
    feed_min = 10.0
    feed_hard_max = 3000.0
    layer_min = 0.08
    hatch_min = 0.30
    layer_max_quality, hatch_max_quality = 0.60, 3.00
    layer_max_extreme, hatch_max_extreme = 0.90, 4.50
    full_process = ("full" in fit_mode) or ("all" in fit_mode) or ("process" in fit_mode)
    aggressive = full_process or ("layer" in fit_mode) or ("hatch" in fit_mode) or ("z" in fit_mode)
    if full_process:
        # Experimental wider range. The UI will warn about quality loss.
        layer_max_extreme = 1.20
        hatch_max_extreme = 6.00

    # Energy range used only by full_process. Reducing J/mm is a last resort to
    # let F rise under the selected current limit; increasing it does not help time,
    # therefore we only adjust it downward for too-short targets.
    energy_bottom_start = max(base.target_energy_bottom_j_per_mm, 1e-9)
    energy_top_start = max(base.target_energy_top_j_per_mm, 1e-9)
    energy_min_factor = 0.60

    for _ in range(18):
        eta = _estimate_time_before_generation(summary, out)
        current_s = max(eta["total_s"], 1.0)
        ratio = current_s / max(target_s, 1.0)  # >1 means we need faster deposition
        if 0.96 <= ratio <= 1.04:
            break

        if ratio > 1.0:
            # Need shorter time.
            if full_process:
                # First remove artificial delay. This is less destructive than reducing energy,
                # but too little pause may overheat the part.
                pause_factor = max(0.70, 1.0 / min(ratio, 1.30))
                out.layer_pause_bottom_s = max(0.0, out.layer_pause_bottom_s * pause_factor)
                out.layer_pause_top_s = max(0.0, out.layer_pause_top_s * pause_factor)

            # Speed up feed while respecting the USER-SET current limit.
            fcap0, fcap1 = _current_limited_feed_cap(out)
            allowed0 = max(feed_min, min(feed_hard_max, fcap0))
            allowed1 = max(feed_min, min(feed_hard_max, fcap1))
            feed_step = min(ratio, 1.35)
            new_f0 = min(out.feed_bottom_mm_min * feed_step, allowed0)
            new_f1 = min(out.feed_top_mm_min * feed_step, allowed1)
            feed_changed = (new_f0 > out.feed_bottom_mm_min + 1e-6) or (new_f1 > out.feed_top_mm_min + 1e-6)
            out.feed_bottom_mm_min = new_f0
            out.feed_top_mm_min = new_f1

            if full_process and not feed_changed:
                # If feed is blocked by current limit, allow lower energy as an explicit
                # quality-risk tradeoff. This keeps current within the selected limit.
                new_e0 = max(energy_bottom_start * energy_min_factor, out.target_energy_bottom_j_per_mm / min(ratio, 1.25))
                new_e1 = max(energy_top_start * energy_min_factor, out.target_energy_top_j_per_mm / min(ratio, 1.25))
                energy_changed = (new_e0 < out.target_energy_bottom_j_per_mm - 1e-6) or (new_e1 < out.target_energy_top_j_per_mm - 1e-6)
                out.target_energy_bottom_j_per_mm = new_e0
                out.target_energy_top_j_per_mm = new_e1
                if energy_changed:
                    # Recompute cap and try another feed increase immediately.
                    fcap0, fcap1 = _current_limited_feed_cap(out)
                    out.feed_bottom_mm_min = min(out.feed_bottom_mm_min * min(ratio, 1.20), max(feed_min, min(feed_hard_max, fcap0)))
                    out.feed_top_mm_min = min(out.feed_top_mm_min * min(ratio, 1.20), max(feed_min, min(feed_hard_max, fcap1)))

            if aggressive:
                # Increase bead productivity geometrically. This is what really reduces
                # layer count / path density, but it may worsen geometry and surface.
                geom_step = min(math.sqrt(ratio), 1.18 if not full_process else 1.25)
                out.layer_height = min(out.layer_height * geom_step, layer_max_extreme)
                out.hatch_spacing = min(out.hatch_spacing * geom_step, hatch_max_extreme)
        else:
            # Need longer time.
            slow_step = max(ratio, 0.65)
            out.feed_bottom_mm_min = max(out.feed_bottom_mm_min * slow_step, feed_min)
            out.feed_top_mm_min = max(out.feed_top_mm_min * slow_step, feed_min)
            if aggressive:
                geom_step = max(math.sqrt(max(ratio, 0.20)), 0.82 if not full_process else 0.75)
                out.layer_height = max(out.layer_height * geom_step, layer_min)
                out.hatch_spacing = max(out.hatch_spacing * geom_step, hatch_min)
            if full_process:
                # If still too fast after reducing speed/geometry, add thermal pauses.
                eta2 = _estimate_time_before_generation(summary, out)
                if eta2["total_s"] < target_s * 0.96:
                    height = max(float(summary.get("size_z", 0.0) or 0.0), 1e-9)
                    n_layers = max(1, int(math.ceil(height / max(out.layer_height, 1e-9))))
                    missing_s = max(0.0, target_s - eta2["total_s"])
                    add_per_layer = min(8.0, missing_s / n_layers)
                    out.layer_pause_bottom_s = min(8.0, out.layer_pause_bottom_s + add_per_layer * 0.65)
                    out.layer_pause_top_s = min(12.0, out.layer_pause_top_s + add_per_layer)

    adj_eta = _estimate_time_before_generation(summary, out)
    plan["adjusted_total_s"] = adj_eta["total_s"]
    err_pct = 100.0 * (adj_eta["total_s"] - target_s) / max(target_s, 1.0)
    plan["error_pct"] = err_pct
    plan["possible"] = abs(err_pct) <= 18.0
    plan["severity"] = "ok" if abs(err_pct) <= 10.0 else ("warn" if abs(err_pct) <= 25.0 else "bad")
    plan["applied_settings"] = {
        "layer_height": out.layer_height,
        "hatch_spacing": out.hatch_spacing,
        "feed_bottom": out.feed_bottom_mm_min,
        "feed_top": out.feed_top_mm_min,
        "energy_bottom": out.target_energy_bottom_j_per_mm,
        "energy_top": out.target_energy_top_j_per_mm,
        "pause_bottom": out.layer_pause_bottom_s,
        "pause_top": out.layer_pause_top_s,
        "current_max": out.current_max_ma,
    }

    fcap0, fcap1 = _current_limited_feed_cap(out)
    max_feed_cap = min(fcap0, fcap1, feed_hard_max)
    wire_eta = _estimate_time_before_generation(summary, out)
    max_wire = max(wire_eta["wire_bottom"], wire_eta["wire_top"])
    needed_i0 = out.target_energy_bottom_j_per_mm * out.feed_bottom_mm_min / max(60.0 * out.voltage_kv, 1e-9)
    needed_i1 = out.target_energy_top_j_per_mm * out.feed_top_mm_min / max(60.0 * out.voltage_kv, 1e-9)

    if not plan["possible"]:
        if adj_eta["total_s"] > target_s:
            plan["messages"].append("Цель слишком короткая для выбранных ограничений тока/скорости/геометрии. Программа приблизилась к цели, но честно показывает, что полностью уложиться не получается.")
        else:
            plan["messages"].append("Цель сильно длиннее расчётного режима. Технически можно тянуть время паузами или очень малой скоростью, но это уже отдельный тепловой режим, а не простая подстройка.")

    if full_process:
        plan["messages"].append("Режим полной подстройки экспериментальный: программа может менять F, Z-шаг, шаг дорожек, паузы и Дж/мм. Итог обязательно проверять коротким TEST-файлом.")
    if out.layer_height > layer_max_quality or out.hatch_spacing > hatch_max_quality:
        plan["messages"].append("Для попадания во время увеличены Z-шаг/шаг дорожек: качество поверхности и точность формы могут стать хуже.")
    if out.layer_height < base.layer_height * 0.70 or out.hatch_spacing < base.hatch_spacing * 0.70:
        plan["messages"].append("Для растягивания времени уменьшены Z-шаг/шаг дорожек: деталь будет дольше, тепловая история изменится, но форма обычно получается аккуратнее.")
    if min(out.target_energy_bottom_j_per_mm / energy_bottom_start, out.target_energy_top_j_per_mm / energy_top_start) < 0.90:
        plan["messages"].append("Для ускорения снижена энергия Дж/мм: риск холодной ванны, тыкания проволоки и непровара выше.")
    if max(out.layer_pause_bottom_s, out.layer_pause_top_s) > max(base.layer_pause_bottom_s, base.layer_pause_top_s) + 0.5:
        plan["messages"].append("Для увеличения времени добавлены паузы между слоями: это может помочь охлаждению, но увеличит тепловую цикличность.")
    if max(out.feed_bottom_mm_min, out.feed_top_mm_min) > 1200:
        plan["messages"].append("Скорость F высокая: возрастает риск холодной ванны, тыкания проволоки и недоформирования острых углов.")
    if max_wire > out.wire_max_mm_s:
        plan["messages"].append(f"Расчётная подача проволоки до {max_wire:.2f} мм/с выше вашей контрольной границы {out.wire_max_mm_s:.2f} мм/с. Это не обрезается автоматически.")
    if max(needed_i0, needed_i1) > out.current_max_ma * 1.001:
        plan["messages"].append(f"Для выбранных Дж/мм и F нужен ток до {max(needed_i0, needed_i1):.1f} мА, но лимит пучка задан {out.current_max_ma:.1f} мА. Ток будет ограничен, энергия фактически снизится.")
    elif min(fcap0, fcap1) < max(out.feed_bottom_mm_min, out.feed_top_mm_min) * 1.02:
        plan["messages"].append(f"Скорость близка к токовому пределу: при текущих Дж/мм и U максимальная скорость около {max_feed_cap:.0f} мм/мин без клиппинга тока.")
    if target_s < base_eta["total_s"] * 0.65:
        plan["messages"].append("Запрошено заметное ускорение: ожидайте ухудшение качества по сравнению с режимом Баланс/Качество.")
    elif target_s > base_eta["total_s"] * 1.50:
        plan["messages"].append("Запрошено заметное замедление: качество может стать лучше, но тепловая история детали изменится; нужны паузы/контроль перегрева.")

    return out, plan

def _sidebar_2d_placement_controls(simple_mode: bool = False):
    with st.sidebar:
        st.header("4B. Размещение на плоскости XY")
        if simple_mode:
            rot_xy = st.selectbox("Поворот фигуры", [0, 90, 180, 270], index=0)
        else:
            rot_xy = st.number_input("Повернуть всю 2D-фигуру, град", min_value=-360.0, max_value=360.0, value=0.0, step=5.0)
        mirror_x = st.checkbox("Зеркально по X", value=False)
        mirror_y = st.checkbox("Зеркально по Y", value=False)
    return rot_xy, mirror_x, mirror_y


def _transform_polygons_2d(polys, rot_xy: float = 0.0, mirror_x: bool = False, mirror_y: bool = False):
    from shapely.affinity import rotate, scale
    out = polys
    if mirror_x or mirror_y:
        out = [scale(p, xfact=(-1.0 if mirror_x else 1.0), yfact=(-1.0 if mirror_y else 1.0), origin="center") for p in out]
    if abs(float(rot_xy or 0.0)) > 1e-12:
        out = [rotate(p, float(rot_xy), origin="center", use_radians=False) for p in out]
    return out


def draw_3d_preview_from_polys(polys, height_mm: float, title: str = "3D-модель"):
    """Simple 3D preview for 2D-based geometry by vertical extrusion."""
    if not polys:
        st.warning("Нет полигонов для 3D-предпросмотра.")
        return
    try:
        from mpl_toolkits.mplot3d.art3d import Poly3DCollection
    except Exception as exc:
        st.warning(f"3D-предпросмотр недоступен: {exc}")
        return

    fig = plt.figure(figsize=(7, 5))
    ax = fig.add_subplot(111, projection="3d")
    side_faces = []
    xmin = ymin = zmin = float("inf")
    xmax = ymax = zmax = float("-inf")

    def _plot_ring(ring_coords, z, **kwargs):
        xs = [p[0] for p in ring_coords]
        ys = [p[1] for p in ring_coords]
        zs = [z for _ in ring_coords]
        ax.plot(xs, ys, zs, **kwargs)

    for poly in polys:
        rings = [list(poly.exterior.coords)] + [list(r.coords) for r in poly.interiors]
        for ring in rings:
            if len(ring) < 2:
                continue
            _plot_ring(ring, 0.0, linewidth=1.1)
            _plot_ring(ring, float(height_mm), linewidth=1.1)
            for i in range(len(ring) - 1):
                x1, y1 = ring[i][0], ring[i][1]
                x2, y2 = ring[i+1][0], ring[i+1][1]
                side_faces.append([(x1, y1, 0.0), (x2, y2, 0.0), (x2, y2, float(height_mm)), (x1, y1, float(height_mm))])
                xmin = min(xmin, x1, x2)
                xmax = max(xmax, x1, x2)
                ymin = min(ymin, y1, y2)
                ymax = max(ymax, y1, y2)

    if side_faces:
        pc = Poly3DCollection(side_faces, alpha=0.22)
        ax.add_collection3d(pc)
    zmin, zmax = 0.0, float(height_mm)
    if xmin == float("inf"):
        xmin, xmax, ymin, ymax = 0.0, 1.0, 0.0, 1.0
    dx = max(xmax - xmin, 1.0)
    dy = max(ymax - ymin, 1.0)
    dz = max(zmax - zmin, 1.0)
    pad_x, pad_y, pad_z = dx * 0.08, dy * 0.08, dz * 0.08
    ax.set_xlim(xmin - pad_x, xmax + pad_x)
    ax.set_ylim(ymin - pad_y, ymax + pad_y)
    ax.set_zlim(zmin - pad_z, zmax + pad_z)
    try:
        ax.set_box_aspect((dx, dy, dz))
    except Exception:
        pass
    ax.set_title(title)
    ax.set_xlabel("X, мм")
    ax.set_ylabel("Y, мм")
    ax.set_zlabel("Z, мм")
    st.pyplot(fig)
    plt.close(fig)


def apply_material_to_settings(settings: ProcessSettings, key: str) -> ProcessSettings:
    mat = MATERIAL_LIBRARY.get(key, MATERIAL_LIBRARY["stainless_steel_12_wire"])
    settings.density_g_cm3 = float(mat.get("density_g_cm3", settings.density_g_cm3))
    settings.wire_diameter_mm = float(mat.get("wire_diameter_mm", settings.wire_diameter_mm))
    settings.target_energy_bottom_j_per_mm = float(mat.get("energy_bottom_j_mm", settings.target_energy_bottom_j_per_mm))
    settings.target_energy_top_j_per_mm = float(mat.get("energy_top_j_mm", settings.target_energy_top_j_per_mm))
    return settings


def show_parameter_effects():
    rows = [
        ["Ток / энергия", "Ванна горячее, лучше плавление", "Расплывание, шапка, боковые наплывы", "Проволока может тыкаться, непровар"],
        ["Скорость F", "Меньше Дж/мм, быстрее", "При слишком большой — холодная ванна", "При слишком малой — перегрев"],
        ["Z-шаг", "Быстрее рост, меньше слоёв", "Грубая поверхность, крупная ванна", "Дольше, но аккуратнее"],
        ["Шаг дорожек", "Меньше дорожек, быстрее", "Борозды между дорожками", "Лишнее перекрытие, перегрев"],
        ["Подача проволоки", "Больше металла", "Шапка/распухание", "Просадка, тонкий валик"],
        ["Контурные проходы", "Лучше форма края", "Сложнее для боковой проволоки", "Без них край грубее"],
        ["W-ретракт", "Меньше хвостов", "При конфликте с M68 — опасно", "Без него больше хвосты"],
    ]
    st.dataframe(pd.DataFrame(rows, columns=["Параметр", "Если увеличить", "Основной риск", "Если уменьшить"]), hide_index=True, use_container_width=True)


def build_settings(summary, mode, material_key, advanced_mode: bool = True):
    recommended = recommend_settings_from_summary(summary, mode, material_key=material_key)

    if not advanced_mode:
        with st.sidebar:
            st.header("5. Автоматический расчёт")
            st.caption("В простом режиме меняются только основные ограничения. Остальное приложение берёт из базы по материалу, геометрии и цели.")
            voltage = st.number_input("Ускоряющее напряжение U, кВ", min_value=1.0, max_value=120.0, value=float(recommended.voltage_kv), step=1.0)
            current_max = st.number_input(
                "Лимит тока пучка E0, мА",
                min_value=1.0, max_value=1000.0, value=float(recommended.current_max_ma), step=5.0,
                help="Программа может использовать ток только до этого лимита. Самостоятельно лимит не повышается."
            )
            if current_max > 100.0:
                st.warning("Лимит выше 100 мА — тяжёлая экспериментальная зона. Проверять только через TEST и штатные interlocks.")
            wire_max = st.number_input(
                "Контрольная подача проволоки, мм/с",
                min_value=0.1, max_value=200.0, value=float(recommended.wire_max_mm_s), step=0.5,
                help="Это граница предупреждения, а не автоматический зажим. Если привод реально может больше — поднимите границу."
            )

            st.header("6. Целевое время")
            target_time_enabled = st.checkbox("Подогнать режим под желаемое время", value=False)
            col_th, col_tm = st.columns(2)
            with col_th:
                target_hours = st.number_input("Часы", min_value=0, max_value=200, value=0, step=1, disabled=not target_time_enabled)
            with col_tm:
                target_minutes = st.number_input("Минуты", min_value=0, max_value=59, value=30, step=5, disabled=not target_time_enabled)
            st.caption("В простом режиме для подгонки времени программа может менять все нужные расчётные параметры, но не повышает лимит тока сама.")

            with st.expander("Дополнительно, обычно не трогать"):
                center_xy = st.checkbox("Центрировать XY вокруг нуля", value=False)
                add_contour = st.checkbox("Добавить 1 контурный проход для края", value=(mode != "Скорость"))
                include_comments = st.checkbox("Комментарии в G-code", value=False, help="Для больших STL лучше выключить: файл будет меньше.")

        settings = replace(
            recommended,
            voltage_kv=voltage,
            current_max_ma=current_max,
            wire_max_mm_s=wire_max,
            center_xy=center_xy,
            contour_passes=(1 if add_contour else 0),
            contour_every_n_layers=1,
            include_comments=include_comments,
            adaptive_thin_wall=True,
            force_contour_on_empty_layers=True,
            adaptive_section_probe=True,
            adaptive_wire_correction=True,
            manual_section_fallback=True,
            projection_fallback_if_empty=False,
        )
        target_total_s = (int(target_hours) * 3600 + int(target_minutes) * 60) if target_time_enabled else 0
        time_plan = {"enabled": False, "messages": [], "target_s": 0.0, "base_total_s": 0.0, "adjusted_total_s": 0.0, "possible": True, "severity": "ok"}
        if target_time_enabled and target_total_s > 0:
            settings, time_plan = _fit_settings_to_target_time(summary, settings, float(target_total_s), "full_process")
        return settings, time_plan

    with st.sidebar:
        st.header("5. Технология")
        st.caption("Значения ниже уже рекомендованы по геометрии и материалу, но их можно править.")
        voltage = st.number_input("Ускоряющее напряжение, кВ", min_value=1.0, max_value=120.0, value=float(recommended.voltage_kv), step=1.0)
        layer_height = st.number_input("Шаг слоя Z, мм", min_value=0.05, max_value=2.0, value=float(recommended.layer_height), step=0.01)
        hatch_spacing = st.number_input("Шаг дорожек, мм", min_value=0.2, max_value=10.0, value=float(recommended.hatch_spacing), step=0.05)
        wire_d = st.number_input("Диаметр проволоки, мм", min_value=0.2, max_value=5.0, value=float(recommended.wire_diameter_mm), step=0.1)
        wire_min = st.number_input("Нижняя контрольная подача проволоки, мм/с", min_value=0.0, max_value=200.0, value=float(recommended.wire_min_mm_s), step=0.1, help="Контрольная граница для предупреждения, не автоматический зажим G-code.")
        wire_max = st.number_input("Верхняя контрольная подача проволоки, мм/с", min_value=0.1, max_value=200.0, value=float(recommended.wire_max_mm_s), step=0.5, help="Если расчётная подача выше этой границы, приложение предупредит. Саму подачу оно не обрежет.")
        density = st.number_input("Плотность, г/см³", min_value=0.5, max_value=25.0, value=float(recommended.density_g_cm3), step=0.1)
        direction = st.selectbox("Рабочее направление / штриховка", ["Y-", "Y+", "X-", "X+"], index=["Y-", "Y+", "X-", "X+"].index(recommended.direction if recommended.direction in ["Y-", "Y+", "X-", "X+"] else "Y-"))
        center_xy = st.checkbox("Центрировать XY вокруг нуля", value=False, help="Для Bormash обычно выключить, чтобы X/Y были положительными.")

        st.header("6. Тепловой профиль")
        e0 = st.number_input("Энергия низ, Дж/мм", min_value=10.0, max_value=1000.0, value=float(recommended.target_energy_bottom_j_per_mm), step=1.0)
        e1 = st.number_input("Энергия верх, Дж/мм", min_value=10.0, max_value=1000.0, value=float(recommended.target_energy_top_j_per_mm), step=1.0)
        f0 = st.number_input("Скорость низ F, мм/мин", min_value=10.0, max_value=3000.0, value=float(recommended.feed_bottom_mm_min), step=10.0, format="%.1f")
        f1 = st.number_input("Скорость верх F, мм/мин", min_value=10.0, max_value=3000.0, value=float(recommended.feed_top_mm_min), step=10.0, format="%.1f")
        st.caption("Скорость движения задаётся в мм/мин. Это же значение записывается в G-code как F для LinuxCNC/G-code.")
        current_max = st.number_input(
            "Верхний лимит тока пучка E0, мА",
            min_value=1.0, max_value=1000.0, value=float(recommended.current_max_ma), step=5.0,
            help="Это программный/технологический лимит для расчёта и проверки. Приложение не поднимает его само при подгонке времени. Значения выше 100 мА для EBAM-пуска считать опасной экспериментальной зоной."
        )
        if current_max > 100.0:
            st.warning("Лимит тока выше 100 мА: это уже тяжёлый тепловой режим. Для реальной установки проверяйте паспорт источника, охлаждение, вакуум, защиту, interlocks и начинайте только с короткого TEST-файла.")
        focus = st.number_input("Фокус E1, мА", min_value=0.0, max_value=3000.0, value=float(recommended.focus_ma), step=1.0)

        st.header("7. Геометрия проходов")
        edge_offset = st.number_input("Отступ от края контура, мм", min_value=0.0, max_value=10.0, value=float(recommended.edge_offset), step=0.1)
        contour_passes = st.number_input("Контурных проходов на слой", min_value=0, max_value=5, value=int(recommended.contour_passes), step=1)
        contour_every = st.number_input("Контур каждые N слоёв", min_value=1, max_value=20, value=int(recommended.contour_every_n_layers), step=1)
        contour_first = st.checkbox("Сначала контур, потом штриховка", value=False)
        thermal_ordering = st.selectbox("Порядок дорожек", ["skip_neighbours", "natural"], index=0, help="skip_neighbours снижает локальный перегрев соседних дорожек.")
        adaptive = st.checkbox("Адаптивная тонкая стенка STL", value=True, help="Если слой слишком тонкий для обычной штриховки, приложение уменьшит отступ/шаг и добавит контурную траекторию вместо пропуска слоя.")
        adaptive_probe = st.checkbox("Устойчивый поиск STL-сечения по Z", value=True, help="Если сечение STL пустое на точной высоте, программа пробует близкие уровни Z. Полезно для чаш, тонких стенок и STL с мелкими численными проблемами.")
        adaptive_wire = st.checkbox("Коррекция проволоки для тонких слоёв", value=True, help="Если адаптивная штриховка уменьшает шаг дорожек, подача проволоки тоже уменьшается, чтобы не было перелива металла.")
        manual_fallback = st.checkbox("Офлайн fallback STL-сечения", value=True, help="Резервная нарезка STL без rtree/интернета. Нужна, если Windows/Trimesh не собирает полигоны сечения.")
        projection_fallback = st.checkbox("Последний fallback: XY-проекция STL", value=False, help="Крайний аварийный режим. Может искажать полые/наклонные модели. Лучше оставить выключенным и использовать только для диагностики.")

        st.header("8. Старт/финиш и безопасность")
        zhop = st.number_input("Z-hop, мм", min_value=0.0, max_value=50.0, value=float(recommended.z_hop_mm), step=0.5)
        use_w = st.checkbox("Использовать W-ретракт", value=True)
        wret = st.number_input("W-ретракт, мм", min_value=0.0, max_value=10.0, value=float(recommended.w_retract_mm), step=0.1)
        lead = st.number_input("Lead-in без проволоки, мм", min_value=0.0, max_value=20.0, value=float(recommended.lead_in_beam_mm), step=0.1)
        soft_start = st.number_input("Мягкий старт, мм", min_value=0.0, max_value=30.0, value=float(recommended.soft_start_mm), step=0.1)
        soft_finish = st.number_input("Мягкий финиш, мм", min_value=0.0, max_value=30.0, value=float(recommended.soft_finish_mm), step=0.1)
        include_comments = st.checkbox("Комментарии в G-code", value=False, help="Выключайте для больших STL: файл будет меньше и быстрее загрузится в LinuxCNC.")

        st.header("9. Целевое время")
        target_time_enabled = st.checkbox("Задать желаемое время изготовления", value=False, help="Программа подстроит расчётные параметры и покажет, реально ли уложиться в выбранное время.")
        col_th, col_tm = st.columns(2)
        with col_th:
            target_hours = st.number_input("Цель, часы", min_value=0, max_value=200, value=0, step=1, disabled=not target_time_enabled)
        with col_tm:
            target_minutes = st.number_input("Цель, минуты", min_value=0, max_value=59, value=30, step=5, disabled=not target_time_enabled)
        target_fit_mode_ru = st.selectbox(
            "Как подстраивать",
            ["Только скорость F", "Скорость + Z-шаг + шаг дорожек", "Все необходимые параметры (экспериментально)"],
            index=2,
            disabled=not target_time_enabled,
            help="В полном режиме программа может менять F, Z-шаг, шаг дорожек, паузы и Дж/мм. Лимит тока пучка она не повышает сама — его задаёт оператор."
        )
        if target_fit_mode_ru.startswith("Только"):
            target_fit_mode = "feed_only"
        elif target_fit_mode_ru.startswith("Скорость"):
            target_fit_mode = "feed_layer_hatch"
        else:
            target_fit_mode = "full_process"
        target_total_s = (int(target_hours) * 3600 + int(target_minutes) * 60) if target_time_enabled else 0

    settings = ProcessSettings(
        voltage_kv=voltage,
        layer_height=layer_height,
        hatch_spacing=hatch_spacing,
        wire_diameter_mm=wire_d,
        wire_min_mm_s=wire_min,
        wire_max_mm_s=wire_max,
        density_g_cm3=density,
        direction=direction,
        center_xy=center_xy,
        target_energy_bottom_j_per_mm=e0,
        target_energy_top_j_per_mm=e1,
        feed_bottom_mm_min=f0,
        feed_top_mm_min=f1,
        focus_ma=focus,
        current_max_ma=current_max,
        z_hop_mm=zhop,
        use_w_retract=use_w,
        w_retract_mm=wret,
        edge_offset=edge_offset,
        contour_passes=int(contour_passes),
        contour_every_n_layers=int(contour_every),
        contour_first=contour_first,
        thermal_ordering=thermal_ordering,
        lead_in_beam_mm=lead,
        soft_start_mm=soft_start,
        soft_finish_mm=soft_finish,
        adaptive_thin_wall=adaptive,
        force_contour_on_empty_layers=adaptive,
        adaptive_section_probe=adaptive_probe,
        adaptive_wire_correction=adaptive_wire,
        manual_section_fallback=manual_fallback,
        projection_fallback_if_empty=projection_fallback,
        include_comments=include_comments,
    )
    time_plan = {"enabled": False, "messages": [], "target_s": 0.0, "base_total_s": 0.0, "adjusted_total_s": 0.0, "possible": True, "severity": "ok"}
    if target_time_enabled and target_total_s > 0:
        settings, time_plan = _fit_settings_to_target_time(summary, settings, float(target_total_s), target_fit_mode)
    return settings, time_plan


def _adaptive_preview_segments(polys, settings, layer_index: int):
    """Build preview paths using the same thin-wall idea as G-code generation.

    In v2.9 the preview used only the normal hatch settings. For thin rings or
    STL sections this could show an empty picture even when generation later
    recovered the layer adaptively. v3.0 preview now follows the same fallback
    path: normal hatch -> thinner hatch -> contour fallback.
    """
    segs = _hatch_segments_for_polygons(polys, settings, layer_index)
    cont = _contour_segments_for_polygons(polys, settings, layer_index)
    preview_note = "обычный режим"

    if settings.adaptive_thin_wall and not segs:
        thin_settings = replace(
            settings,
            edge_offset=max(0.0, min(settings.edge_offset * settings.thin_wall_edge_offset_factor, settings.edge_offset, 0.35)),
            hatch_spacing=max(0.35, min(settings.hatch_spacing * settings.thin_wall_hatch_spacing_factor, settings.hatch_spacing)),
            min_segment_length=max(0.25, min(settings.thin_wall_min_segment_length, settings.min_segment_length)),
        )
        segs_retry = _hatch_segments_for_polygons(polys, thin_settings, layer_index)
        if segs_retry:
            segs = segs_retry
            preview_note = "адаптивная тонкая штриховка"

    if settings.adaptive_thin_wall and settings.force_contour_on_empty_layers and not segs and not cont:
        contour_settings = replace(
            settings,
            contour_passes=max(1, settings.contour_passes),
            edge_offset=max(0.0, min(settings.edge_offset * settings.thin_wall_edge_offset_factor, settings.edge_offset, 0.35)),
            min_segment_length=max(0.25, min(settings.thin_wall_min_segment_length, settings.min_segment_length)),
        )
        cont_retry = _contour_segments_for_polygons(polys, contour_settings, layer_index)
        if cont_retry:
            cont = cont_retry
            preview_note = "контурный fallback для тонкого слоя"

    return segs, cont, preview_note


def draw_preview_from_polys(polys, settings, layer_index=1, title="Предпросмотр"):
    if not polys:
        st.warning("На выбранной высоте сечение STL не найдено. Попробуйте другой Z или включите устойчивый поиск STL-сечения.")
        return
    segs, cont, note = _adaptive_preview_segments(polys, settings, layer_index)
    fig, ax = plt.subplots(figsize=(7, 5))
    for p in polys:
        x, y = p.exterior.xy
        ax.plot(x, y, linewidth=1.5)
        for hole in p.interiors:
            hx, hy = hole.xy
            ax.plot(hx, hy, linewidth=1.0)
    for s in segs[:1200]:
        ax.plot([s[0], s[2]], [s[1], s[3]], linewidth=0.7)
    for s in cont[:800]:
        ax.plot([s[0], s[2]], [s[1], s[3]], linewidth=1.0, linestyle="--")
    ax.set_aspect('equal', 'box')
    ax.set_title(f"{title}: hatch={len(segs)}, contour={len(cont)}")
    ax.set_xlabel("X, мм")
    ax.set_ylabel("Y, мм")
    if not segs and not cont:
        ax.text(0.5, 0.5, "На этом сечении нет траекторий", ha="center", va="center", transform=ax.transAxes)
        st.warning("Сечение найдено, но траектории не построились. Уменьшите отступ от края, шаг дорожек или минимальную длину сегмента.")
    else:
        st.caption(f"Предпросмотр: {note}. Показано hatch={len(segs)}, contour={len(cont)}.")
    st.pyplot(fig)
    plt.close(fig)


# ------------------------- sidebar source -------------------------
with st.sidebar:
    st.header("1. Режим работы")
    ui_mode_ru = st.radio("Интерфейс", ["Простой", "Расширенный"], index=0, horizontal=True)
    advanced_mode = ui_mode_ru == "Расширенный"
    if advanced_mode:
        st.caption("Расширенный режим: доступны все технологические настройки и диагностика.")
    else:
        st.caption("Простой режим: выбери геометрию, материал и цель — остальное рассчитывается автоматически.")
    if st.button("Очистить кэш геометрии", help="Полезно, если меняли файлы с тем же именем или хотите освободить память."):
        st.cache_data.clear()
        st.rerun()
    st.divider()

    st.header("2. Геометрия")
    src_type = st.selectbox("Источник", ["STL 3D", "Стандартная фигура", "DXF 2D + высота", "CSV X,Y + высота"], index=0)
    st.header("3. Материал и цель")
    mat_labels = {k: v["name_ru"] for k, v in MATERIAL_LIBRARY.items()}
    material_key = st.selectbox("Материал", list(mat_labels.keys()), format_func=lambda k: mat_labels[k], index=0)
    st.caption(MATERIAL_LIBRARY[material_key].get("note_ru", ""))
    mode = st.selectbox("Цель", ["Качество", "Баланс", "Скорость"], index=1, help="Качество — аккуратнее и медленнее; Баланс — стартовый режим; Скорость — быстрее, но выше риск ухудшения поверхности и формы.")

# ------------------------- load geometry -------------------------
raw_mesh = None
mesh = None
polys = None
summary = None
height_2d = None
source_info = ""

if src_type == "Стандартная фигура":
    with st.sidebar:
        st.header("4. Стандартная фигура")
        shape_ru = st.selectbox(
            "Фигура",
            ["Прямоугольник", "Квадрат", "Круг", "Кольцо", "Эллипс", "Треугольник", "Многоугольник", "Звезда", "Капсула/овал"],
            index=0,
        )
        height_2d = st.number_input("Высота построения Z, мм", min_value=0.1, max_value=1000.0, value=100.0, step=1.0)
        shape_map = {
            "Прямоугольник": "rectangle",
            "Квадрат": "square",
            "Круг": "circle",
            "Кольцо": "ring",
            "Эллипс": "ellipse",
            "Треугольник": "triangle",
            "Многоугольник": "regular_polygon",
            "Звезда": "star",
            "Капсула/овал": "capsule",
        }
        params = {"resolution": 128}
        if shape_ru == "Прямоугольник":
            params["width_x"] = st.number_input("Ширина X, мм", min_value=0.1, max_value=2000.0, value=20.0, step=1.0)
            params["length_y"] = st.number_input("Длина Y, мм", min_value=0.1, max_value=2000.0, value=100.0, step=1.0)
            st.caption("Прямоугольник удобен для стенок и пластин. X — ширина набора дорожек, Y — длина рабочего хода.")
        elif shape_ru == "Квадрат":
            params["side"] = st.number_input("Сторона, мм", min_value=0.1, max_value=2000.0, value=50.0, step=1.0)
            st.caption("Квадрат — частный случай прямоугольника с одинаковыми X и Y.")
        elif shape_ru == "Круг":
            params["radius"] = st.number_input("Радиус, мм", min_value=0.1, max_value=1000.0, value=30.0, step=1.0)
            st.caption("Круг формируется штриховкой внутри круглого сечения; для тонкой стенки лучше выбирать Кольцо.")
        elif shape_ru == "Кольцо":
            outer_r = st.number_input("Внешний радиус, мм", min_value=0.1, max_value=1000.0, value=40.0, step=1.0)
            params["outer_radius"] = outer_r
            params["inner_radius"] = st.number_input("Внутренний радиус, мм", min_value=0.0, max_value=max(0.01, outer_r-0.01), value=min(25.0, outer_r*0.6), step=1.0)
            st.caption("Кольцо — наружный контур минус внутренний. Если стенка тонкая, уменьшайте шаг дорожек и edge_offset.")
        elif shape_ru == "Эллипс":
            params["radius_x"] = st.number_input("Радиус X, мм", min_value=0.1, max_value=1000.0, value=45.0, step=1.0)
            params["radius_y"] = st.number_input("Радиус Y, мм", min_value=0.1, max_value=1000.0, value=25.0, step=1.0)
            st.caption("Эллипс — полезен для овальных сечений. Больший радиус увеличивает длину дорожек и время.")
        elif shape_ru == "Треугольник":
            params["base"] = st.number_input("Основание X, мм", min_value=0.1, max_value=2000.0, value=60.0, step=1.0)
            params["triangle_height"] = st.number_input("Высота треугольника Y, мм", min_value=0.1, max_value=2000.0, value=50.0, step=1.0)
            st.caption("В острых углах траектории короткие. Уменьшайте min_segment_length и включайте контур осторожно.")
        elif shape_ru == "Многоугольник":
            params["sides"] = st.number_input("Количество сторон", min_value=3, max_value=64, value=6, step=1)
            params["radius"] = st.number_input("Радиус описанной окружности, мм", min_value=0.1, max_value=1000.0, value=35.0, step=1.0)
            params["rotation_deg"] = st.number_input("Поворот, град", min_value=-360.0, max_value=360.0, value=0.0, step=5.0)
            st.caption("Больше сторон — ближе к кругу; меньше сторон — больше углов и локальных перегревов на вершинах.")
        elif shape_ru == "Звезда":
            params["points"] = st.number_input("Лучей", min_value=3, max_value=32, value=5, step=1)
            outer_r = st.number_input("Внешний радиус, мм", min_value=0.1, max_value=1000.0, value=40.0, step=1.0)
            params["outer_radius"] = outer_r
            params["inner_radius"] = st.number_input("Внутренний радиус, мм", min_value=0.1, max_value=max(0.1, outer_r*0.95), value=min(20.0, outer_r*0.5), step=1.0)
            params["rotation_deg"] = st.number_input("Поворот, град", min_value=-360.0, max_value=360.0, value=-90.0, step=5.0)
            st.caption("Звезда сложная для наплавки: острые углы любят перегреваться и деформироваться.")
        else:
            params["width_x"] = st.number_input("Ширина X, мм", min_value=0.1, max_value=1000.0, value=25.0, step=1.0)
            params["length_y"] = st.number_input("Длина Y, мм", min_value=0.1, max_value=2000.0, value=100.0, step=1.0)
            st.caption("Капсула — прямой участок с полукруглыми торцами. Хороший вариант без острых углов.")
    rot_xy, mirror_2d_x, mirror_2d_y = _sidebar_2d_placement_controls(simple_mode=not advanced_mode)
    try:
        polys = _cached_standard_shape(shape_map[shape_ru], tuple(sorted(params.items())))
        polys = _transform_polygons_2d(polys, rot_xy, mirror_2d_x, mirror_2d_y)
        base_summary = polygon_summary(polys, height_2d)
    except Exception as exc:
        st.error(f"Не удалось построить стандартную фигуру: {exc}")
        st.stop()
    settings, time_plan = build_settings(base_summary, mode, material_key, advanced_mode=advanced_mode)
    try:
        from shapely.affinity import translate
        if not settings.center_xy:
            from shapely import unary_union
            u = unary_union(polys)
            minx, miny, _, _ = u.bounds
            polys = [translate(p, xoff=-minx, yoff=-miny) for p in polys]
        summary = polygon_summary(polys, height_2d)
        summary["source_type"] = "standard shape: " + shape_ru
        source_info = "Стандартная фигура: " + shape_ru
    except Exception as exc:
        st.error(f"Ошибка подготовки стандартной фигуры: {exc}")
        st.stop()

elif src_type == "STL 3D":
    uploaded = st.sidebar.file_uploader("Загрузить STL", type=["stl"])
    if uploaded is None:
        st.info("Загрузите STL-файл слева.")
        st.stop()
    with st.sidebar:
        st.header("4. Положение STL")
        if advanced_mode:
            axis_order = st.selectbox("Какие исходные оси станут X/Y/Z", ["XYZ", "XZY", "YXZ", "YZX", "ZXY", "ZYX"], index=0, help="Если деталь лежит на боку, выберите порядок, где высота модели станет выходной осью Z.")
            col_rx, col_ry, col_rz = st.columns(3)
            with col_rx:
                rotate_x = st.number_input("Rx", min_value=-360.0, max_value=360.0, value=0.0, step=90.0)
            with col_ry:
                rotate_y = st.number_input("Ry", min_value=-360.0, max_value=360.0, value=0.0, step=90.0)
            with col_rz:
                rotate_z = st.number_input("Rz", min_value=-360.0, max_value=360.0, value=0.0, step=90.0)
            mirror_x = st.checkbox("Зеркально STL по X", value=False)
            mirror_y = st.checkbox("Зеркально STL по Y", value=False)
            mirror_z = st.checkbox("Зеркально STL по Z", value=False)
            st.caption("После ориентации модель автоматически ставится нижней точкой на Z=0. Центрирование XY задаётся ниже.")
        else:
            preset = st.selectbox(
                "Быстрый вариант",
                ["Как в STL", "Высота была по X", "Высота была по Y"],
                index=0,
                help="Если после загрузки высота/габариты выглядят неправильно, выберите другой вариант и посмотрите preview."
            )
            axis_order = "XYZ"
            if preset == "Высота была по X":
                axis_order = "YZX"
            elif preset == "Высота была по Y":
                axis_order = "XZY"
            rotate_x, rotate_y, rotate_z = 0.0, 0.0, 0.0
            st.caption("Ниже можно вручную поменять направления по осям.")
            col_fx, col_fy, col_fz = st.columns(3)
            with col_fx:
                mirror_x = st.checkbox("-X", value=False)
            with col_fy:
                mirror_y = st.checkbox("-Y", value=False)
            with col_fz:
                mirror_z = st.checkbox("-Z", value=False)
            rotate_z = st.selectbox("Поворот на столе вокруг Z", [0, 90, 180, 270], index=0)
            st.caption("Модель автоматически ставится нижней точкой на Z=0.")
    try:
        raw_mesh = _cached_mesh_from_bytes(uploaded.getvalue(), ".stl")
        orient_settings = ProcessSettings(axis_order=axis_order, rotate_x_deg=rotate_x, rotate_y_deg=rotate_y, rotate_z_deg=rotate_z, mirror_x=mirror_x, mirror_y=mirror_y, mirror_z=mirror_z)
        mesh_for_summary = normalize_mesh(raw_mesh, orient_settings)
        base_summary = mesh_summary(mesh_for_summary)
    except Exception as exc:
        st.error(f"Не удалось прочитать/ориентировать STL: {exc}")
        st.stop()
    settings, time_plan = build_settings(base_summary, mode, material_key, advanced_mode=advanced_mode)
    settings.axis_order = axis_order
    settings.rotate_x_deg = rotate_x
    settings.rotate_y_deg = rotate_y
    settings.rotate_z_deg = rotate_z
    settings.mirror_x = mirror_x
    settings.mirror_y = mirror_y
    settings.mirror_z = mirror_z
    try:
        mesh = normalize_mesh(raw_mesh, settings)
        summary = mesh_summary(mesh)
        source_info = "STL"
    except Exception as exc:
        st.error(f"Ошибка подготовки STL: {exc}")
        st.stop()

elif src_type == "DXF 2D + высота":
    uploaded = st.sidebar.file_uploader("Загрузить DXF", type=["dxf"])
    height_2d = st.sidebar.number_input("Высота построения, мм", min_value=0.1, max_value=1000.0, value=100.0, step=1.0)
    rot_xy, mirror_2d_x, mirror_2d_y = _sidebar_2d_placement_controls(simple_mode=not advanced_mode)
    if uploaded is None:
        st.info("Загрузите 2D DXF с замкнутым контуром слева.")
        st.stop()
    try:
        polys = _cached_dxf_polygons_from_bytes(uploaded.getvalue())
        polys = _transform_polygons_2d(polys, rot_xy, mirror_2d_x, mirror_2d_y)
        base_summary = polygon_summary(polys, height_2d)
    except Exception as exc:
        st.error(f"Не удалось прочитать DXF: {exc}")
        st.stop()
    settings, time_plan = build_settings(base_summary, mode, material_key, advanced_mode=advanced_mode)
    # normalize is done inside generate_from_polygons; for preview shift here similarly not necessary if user selected center later
    try:
        from shapely.affinity import translate
        if not settings.center_xy:
            from shapely import unary_union
            u = unary_union(polys)
            minx, miny, _, _ = u.bounds
            polys = [translate(p, xoff=-minx, yoff=-miny) for p in polys]
        summary = polygon_summary(polys, height_2d)
        source_info = "DXF"
    except Exception as exc:
        st.error(f"Ошибка подготовки DXF: {exc}")
        st.stop()

else:
    uploaded = st.sidebar.file_uploader("Загрузить CSV", type=["csv", "txt"])
    height_2d = st.sidebar.number_input("Высота построения, мм", min_value=0.1, max_value=1000.0, value=100.0, step=1.0)
    rot_xy, mirror_2d_x, mirror_2d_y = _sidebar_2d_placement_controls(simple_mode=not advanced_mode)
    st.sidebar.caption("CSV: две первые колонки должны быть X,Y. Первая строка может быть заголовком.")
    if uploaded is None:
        st.info("Загрузите CSV с точками контура X,Y слева.")
        st.stop()
    text = uploaded.getvalue().decode("utf-8-sig", errors="replace")
    try:
        polys = _cached_csv_polygons_from_text(text)
        polys = _transform_polygons_2d(polys, rot_xy, mirror_2d_x, mirror_2d_y)
        base_summary = polygon_summary(polys, height_2d)
    except Exception as exc:
        st.error(f"Не удалось прочитать CSV: {exc}")
        st.stop()
    settings, time_plan = build_settings(base_summary, mode, material_key, advanced_mode=advanced_mode)
    try:
        from shapely.affinity import translate
        if not settings.center_xy:
            from shapely import unary_union
            u = unary_union(polys)
            minx, miny, _, _ = u.bounds
            polys = [translate(p, xoff=-minx, yoff=-miny) for p in polys]
        summary = polygon_summary(polys, height_2d)
        source_info = "CSV"
    except Exception as exc:
        st.error(f"Ошибка подготовки CSV: {exc}")
        st.stop()

# ------------------------- main tabs -------------------------
tabs = st.tabs(["🏠 Сводка", "📘 Инструкция", "👁️ Предпросмотр", "⚙️ Генерация", "🧩 JSON"])

with tabs[0]:
    st.caption(f"Режим интерфейса: {ui_mode_ru}. Технологическая цель: {mode}. Материал: {mat_labels[material_key]}.")
    col_a, col_b = st.columns([1, 1])
    with col_a:
        st.subheader(f"Анализ геометрии: {source_info}")
        st.table(pd.DataFrame([summary]).T.rename(columns={0: "значение"}))
        if src_type == "STL 3D" and not summary["is_watertight"]:
            st.warning("STL не замкнутый. Сечения могут получиться неполными. Для точного расчёта лучше замкнутая STL-модель.")
    with col_b:
        st.subheader("Расчётные значения")
        height = max(float(summary["size_z"]), 1e-9)
        n_layers = int(math.ceil(height / settings.layer_height))
        area_wire = settings.wire_area_mm2()
        current_bottom_need = settings.target_energy_bottom_j_per_mm * settings.feed_bottom_mm_min / (60 * settings.voltage_kv)
        current_top_need = settings.target_energy_top_j_per_mm * settings.feed_top_mm_min / (60 * settings.voltage_kv)
        current_bottom = max(settings.current_min_ma, min(settings.current_max_ma, current_bottom_need))
        current_top = max(settings.current_min_ma, min(settings.current_max_ma, current_top_need))
        wire_bottom = settings.layer_height * (settings.feed_bottom_mm_min/60) * settings.hatch_spacing / area_wire
        wire_top = settings.layer_height * (settings.feed_top_mm_min/60) * settings.hatch_spacing / area_wire
        eta = _estimate_time_before_generation(summary, settings)
        calc_df = pd.DataFrame({
            "Параметр": [
                "Слоёв", "Скорость низ/верх, мм/мин", "Ток низ нужен, мА", "Ток верх нужен, мА", "Ток в G-code низ/верх, мА", "Лимит тока E0, мА",
                "Проволока низ, мм/с", "Проволока верх, мм/с", "Контроль подачи, мм/с",
                "Площадь проволоки, мм²", "Контурных проходов",
                "Время активной наплавки, прибл.", "Полное время с паузами, прибл."
            ],
            "Значение": [
                n_layers, f"{settings.feed_bottom_mm_min:.1f} / {settings.feed_top_mm_min:.1f}", round(current_bottom_need,3), round(current_top_need,3), f"{current_bottom:.3f} / {current_top:.3f}", round(settings.current_max_ma, 3),
                round(wire_bottom,3), round(wire_top,3), f"{settings.wire_min_mm_s:.1f}...{settings.wire_max_mm_s:.1f}",
                round(area_wire,3), settings.contour_passes,
                _fmt_hm(eta["active_s"]), _fmt_hm(eta["total_s"])
            ]
        })
        st.table(calc_df.set_index("Параметр"))

        gate_level, gate_title, gate_messages = _safety_gate_status(
            src_type, summary, settings, time_plan, n_layers, wire_bottom, wire_top, current_bottom_need, current_top_need
        )
        gate_text = "\n".join(f"- {m}" for m in gate_messages)
        if gate_level == "bad":
            st.error(f"{gate_title}\n\n{gate_text}")
        elif gate_level == "warn":
            st.warning(f"{gate_title}\n\n{gate_text}")
        else:
            st.success(f"{gate_title}\n\n{gate_text}")

        if time_plan.get("enabled"):
            st.markdown("### Подгонка под заданное время")
            target_text = _fmt_hm(time_plan.get("target_s", 0))
            base_text = _fmt_hm(time_plan.get("base_total_s", 0))
            adj_text = _fmt_hm(time_plan.get("adjusted_total_s", 0))
            delta = time_plan.get("error_pct", 0.0)
            if time_plan.get("severity") == "ok":
                st.success(f"Цель: {target_text}. Было примерно {base_text}, после подстройки примерно {adj_text} ({delta:+.1f}%).")
            elif time_plan.get("severity") == "warn":
                st.warning(f"Цель: {target_text}. Было примерно {base_text}, после подстройки примерно {adj_text} ({delta:+.1f}%). Нужна проверка на TEST-файле.")
            else:
                st.error(f"Цель: {target_text}. Было примерно {base_text}, после подстройки примерно {adj_text} ({delta:+.1f}%). Вероятно, в это время логично не уложиться без ухудшения режима или выхода за ограничения.")
            applied = time_plan.get("applied_settings", {})
            if applied:
                st.table(pd.DataFrame({
                    "Параметр": ["Z-шаг, мм", "Шаг дорожек, мм", "Скорость низ, мм/мин", "Скорость верх, мм/мин", "Энергия низ, Дж/мм", "Энергия верх, Дж/мм", "Пауза низ/верх, с", "Лимит тока E0, мА"],
                    "Применено": [
                        round(applied.get("layer_height", settings.layer_height), 3),
                        round(applied.get("hatch_spacing", settings.hatch_spacing), 3),
                        round(applied.get("feed_bottom", settings.feed_bottom_mm_min), 1),
                        round(applied.get("feed_top", settings.feed_top_mm_min), 1),
                        round(applied.get("energy_bottom", settings.target_energy_bottom_j_per_mm), 1),
                        round(applied.get("energy_top", settings.target_energy_top_j_per_mm), 1),
                        f"{applied.get('pause_bottom', settings.layer_pause_bottom_s):.2f} / {applied.get('pause_top', settings.layer_pause_top_s):.2f}",
                        round(applied.get("current_max", settings.current_max_ma), 1),
                    ]
                }).set_index("Параметр"))
            for msg in time_plan.get("messages", []):
                st.warning(msg)
        max_wire_calc = max(wire_bottom, wire_top)
        if max_wire_calc > settings.wire_max_mm_s:
            st.warning(
                f"Расчётная подача проволоки {max_wire_calc:.3f} мм/с выше вашей контрольной границы {settings.wire_max_mm_s:.3f} мм/с. "
                "В v4.2 это НЕ ошибка и НЕ автоматический зажим: G-code будет рассчитан с фактической требуемой подачей. "
                "Если механизм подачи реально допускает такую скорость — увеличьте контрольную границу. Если нет — уменьшите Z-шаг, шаг дорожек или скорость F."
            )
        elif max_wire_calc > settings.wire_max_mm_s * 0.85:
            st.info("Подача проволоки близко к верхней контрольной границе. Для первого теста проверьте устойчивость подачи и W-ретракт на сухом прогоне.")
        if current_bottom_need > settings.current_max_ma or current_top_need > settings.current_max_ma:
            st.error(
                f"Для выбранных Дж/мм и F нужен ток до {max(current_bottom_need, current_top_need):.2f} мА, "
                f"но лимит пучка задан {settings.current_max_ma:.2f} мА. "
                "В G-code ток будет ограничен этим лимитом, поэтому фактическая энергия будет ниже расчётной. "
                "Можно поднять лимит тока, уменьшить F или снизить требуемые Дж/мм."
            )
        elif max(current_bottom_need, current_top_need) > settings.current_max_ma * 0.85:
            st.info("Ток пучка близко к заданному лимиту. Для первого теста оставьте запас, особенно на тонких/острых участках.")
        if settings.contour_passes > 0:
            st.warning("Контурные проходы улучшают край, но для боковой подачи проволоки часть контура может идти в неидеальном направлении. Проверять на коротком тесте.")

with tabs[1]:
    st.subheader("Инструкция и подсказки")
    st.markdown(
        """
        ### Быстрый маршрут для новичка
        1. Выбери **Простой** режим.
        2. Загрузи STL или выбери стандартную фигуру.
        3. Выбери материал и цель: **Качество / Баланс / Скорость**.
        4. Открой **Предпросмотр** и проверь, что сечение и штриховка похожи на ожидаемую деталь.
        5. Вкладка **Генерация** → сначала включи **TEST-файл** до 10–15 мм.
        6. Скачай `.ngc` и `audit.txt`, проверь в viewer/LinuxCNC, затем делай сухой прогон без луча и проволоки.

        ### Когда нужен расширенный режим
        Расширенный режим нужен, если надо вручную менять Z-шаг, шаг дорожек, энергию Дж/мм, скорость F,
        токовый лимит, W-ретракт, контурные проходы, fallback-сечения STL или подгонку под время.
        """
    )
    st.markdown("### Как параметры влияют на форму и качество")
    show_parameter_effects()
    st.markdown(
        "**Практическое правило:** если фигура расплывается и верх блестит — снижать энергию/ток или увеличивать скорость. "
        "Если проволока тыкается и валик рвётся — энергии мало, проволоки много или Z-шаг завышен."
    )
    st.markdown(
        "**По стандартным фигурам:** увеличение размера X/Y/R увеличивает длину активной траектории и расход проволоки; "
        "острые углы у треугольника, звезды и малого многоугольника требуют меньшей скорости/меньшего контурного усиления; "
        "тонкие кольца требуют меньшего `edge_offset`, меньшего `hatch_spacing` и меньшего `min_segment_length`."
    )

with tabs[2]:
    st.subheader("Предпросмотр")
    col_p1, col_p2 = st.columns([1, 1])
    with col_p1:
        st.markdown("### 3D-модель")
        if src_type == "STL 3D":
            try:
                fig = plt.figure(figsize=(7, 5))
                ax = fig.add_subplot(111, projection="3d")
                verts = mesh.vertices
                faces = mesh.faces
                step = max(1, len(faces)//5000)
                tri = verts[faces[::step]]
                from mpl_toolkits.mplot3d.art3d import Poly3DCollection
                pc = Poly3DCollection(tri, alpha=0.25)
                ax.add_collection3d(pc)
                ax.auto_scale_xyz(verts[:,0], verts[:,1], verts[:,2])
                try:
                    dx = max(float(summary.get("size_x", 1.0)), 1.0)
                    dy = max(float(summary.get("size_y", 1.0)), 1.0)
                    dz = max(float(summary.get("size_z", 1.0)), 1.0)
                    ax.set_box_aspect((dx, dy, dz))
                except Exception:
                    pass
                ax.set_xlabel("X, мм")
                ax.set_ylabel("Y, мм")
                ax.set_zlabel("Z, мм")
                st.pyplot(fig)
                plt.close(fig)
            except Exception as exc:
                st.warning(f"3D-предпросмотр недоступен: {exc}")
        else:
            try:
                draw_3d_preview_from_polys(polys, float(height_2d), title=f"3D-модель: {source_info}")
            except Exception as exc:
                st.warning(f"3D-предпросмотр не построен: {exc}")

    with col_p2:
        st.markdown("### Сечение и траектории")
        if src_type == "STL 3D":
            z_fraction = st.slider("Сечение по высоте, доля Z", 0.01, 0.99, 0.50, 0.01)
            zmid = float(summary["size_z"]) * z_fraction
            try:
                probe = settings.layer_height * settings.section_probe_fraction if settings.adaptive_section_probe else 0.0
                sec_polys = _section_polygons_at_z(mesh, zmid, probe_radius=probe)
                used_z = zmid
                if not sec_polys and settings.adaptive_section_probe:
                    best = []
                    best_z = zmid
                    search_span = max(settings.layer_height * 3.0, float(summary["size_z"]) * 0.02)
                    for k in range(1, 21):
                        dz = search_span * k / 20.0
                        for zz in (zmid - dz, zmid + dz):
                            if zz <= 0 or zz >= float(summary["size_z"]):
                                continue
                            cand = _section_polygons_at_z(mesh, zz, probe_radius=probe)
                            if cand and sum(p.area for p in cand) > sum(p.area for p in best):
                                best = cand
                                best_z = zz
                    sec_polys = best
                    used_z = best_z

                layer_index = max(1, int(round(zmid / max(settings.layer_height, 1e-9))) + 1)
                title = f"Сечение Z={zmid:.2f} мм" if abs(used_z - zmid) < 1e-6 else f"Сечение Z={zmid:.2f} мм, найдено рядом Z={used_z:.2f} мм"
                draw_preview_from_polys(sec_polys, settings, layer_index, title=title)
            except Exception as exc:
                st.warning(f"Предпросмотр не построен: {exc}")
        else:
            try:
                draw_preview_from_polys(polys, settings, 1, title=f"Контур {source_info}")
            except Exception as exc:
                st.warning(f"Предпросмотр не построен: {exc}")

with tabs[3]:
    st.subheader("Генерация")
    st.caption("Сохраняйте аудит вместе с G-code. Он показывает диапазоны, предупреждения и расчётные режимы.")

    total_layers_est = int(math.ceil(float(summary["size_z"]) / max(settings.layer_height, 1e-9)))
    st.info(f"Оценка: будет до {total_layers_est} слоёв. Для сложных STL генерация может занимать 1–5 минут на слабом ПК. В v4.2 сохранён прогресс по слоям, чтобы окно не выглядело зависшим.")

    col_g1, col_g2 = st.columns([1, 1])
    with col_g1:
        test_mode = st.checkbox("Сначала сделать короткий TEST-файл", value=False, help="Генерирует только первые слои до указанной высоты. Полезно для проверки Чаши и тяжёлых STL без долгого ожидания полного файла.")
    with col_g2:
        test_height = st.number_input("Высота TEST, мм", min_value=1.0, max_value=max(1.0, float(summary["size_z"])), value=min(15.0, max(1.0, float(summary["size_z"]))), step=1.0)

    if test_mode:
        test_layers = max(1, int(math.ceil(test_height / max(settings.layer_height, 1e-9))))
        st.warning(f"Будет создан НЕ полный файл, а тест до Z≈{test_layers * settings.layer_height:.1f} мм: {test_layers} слоёв из {total_layers_est}.")
    else:
        test_layers = 0
        if total_layers_est > 250:
            st.warning("Полная STL-генерация может быть долгой и файл будет большим. Не закрывайте вкладку, пока идёт прогресс. Для первой проверки лучше включить TEST-файл до Z10–15 мм.")

    if st.button("Сгенерировать G-code", type="primary"):
        run_settings = replace(settings, max_layers_to_generate=int(test_layers), progress_update_every_layers=max(1, total_layers_est // 200))
        progress_bar = st.progress(0.0)
        status_box = st.empty()

        def _progress(done: int, total: int, stage: str):
            total = max(int(total), 1)
            done = max(0, min(int(done), total))
            progress_bar.progress(done / total)
            status_box.write(f"{stage}: слой {done}/{total}")

        with st.spinner("Слайсинг/генерация G-code... окно может работать несколько минут, это нормально для STL."):
            try:
                if src_type == "STL 3D":
                    result = generate_from_mesh(raw_mesh, run_settings, progress_callback=_progress)
                else:
                    result = generate_from_polygons_2d(polys, float(height_2d), run_settings, progress_callback=_progress)
            except Exception as exc:
                st.error(f"Ошибка генерации: {exc}")
                st.stop()
        progress_bar.progress(1.0)
        status_box.write("Готово")
        st.success("G-code сгенерирован")
        if result.stats.get("estimated_total_time_s") is not None:
            st.info(
                "Оценка времени по фактическим траекториям: "
                f"активная наплавка {_fmt_hm(result.stats.get('estimated_active_time_s', 0))}, "
                f"полное технологическое время примерно {_fmt_hm(result.stats.get('estimated_total_time_s', 0))}."
            )
        if result.stats.get("target_total_time_s", 0.0):
            err = result.stats.get("target_time_error_pct", 0.0)
            msg = (
                f"Целевое время: {_fmt_hm(result.stats.get('target_total_time_s', 0))}; "
                f"по фактическим траекториям получилось {_fmt_hm(result.stats.get('estimated_total_time_s', 0))} ({err:+.1f}%)."
            )
            if abs(err) <= 15.0:
                st.success(msg)
            else:
                st.warning(msg + " После построения реальных траекторий цель не совпала точно; скорректируйте время или параметры и перегенерируйте.")
        if result.stats.get("wire_above_control_limit"):
            st.warning(
                f"В G-code есть подача проволоки до {result.stats.get('wire_max_calculated_mm_s', 0):.3f} мм/с, "
                f"что выше контрольной границы {settings.wire_max_mm_s:.3f} мм/с. Значение не обрезано автоматически."
            )

        suffix = "TEST" if test_mode else "FULL"
        result_zip = _make_result_zip(result, settings_to_json(run_settings), suffix)
        st.download_button(
            "Скачать весь комплект .zip",
            result_zip,
            file_name=f"ebam_result_v42_{suffix}.zip",
            mime="application/zip",
            type="primary",
        )
        st.download_button("Скачать G-code .ngc", result.gcode, file_name=f"ebam_generated_v42_{suffix}.ngc", mime="text/plain")
        st.download_button("Скачать таблицу слоёв .csv", result.layer_csv, file_name=f"ebam_layers_v42_{suffix}.csv", mime="text/csv")
        st.download_button("Скачать аудит .txt", result.audit_text, file_name=f"ebam_audit_v42_{suffix}.txt", mime="text/plain")
        st.subheader("Сводка")
        st.json(result.stats)
        if result.stats.get("gcode_size_mb", 0) > settings.max_gcode_size_mb_warning:
            st.warning("G-code получился большим. Для LinuxCNC лучше сначала открыть в просмотрщике/симуляторе и проверить загрузку программы.")
        st.subheader("Первые строки G-code")
        st.code("\n".join(result.gcode.splitlines()[:100]), language="gcode")
        st.subheader("Аудит")
        st.text(result.audit_text[:16000])

with tabs[4]:
    st.subheader("Параметры JSON")
    st.caption("Можно сохранить профиль режима и потом восстановить вручную/через CLI.")
    st.code(settings_to_json(settings), language="json")


st.markdown("---")
st.caption("By Керенцев Максим")
