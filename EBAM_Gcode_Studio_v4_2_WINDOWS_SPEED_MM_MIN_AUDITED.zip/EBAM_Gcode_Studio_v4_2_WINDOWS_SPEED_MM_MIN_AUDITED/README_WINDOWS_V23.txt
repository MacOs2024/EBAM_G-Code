EBAM G-code Studio v2.4.4 Windows start

1) Recommended Python: 3.12.x or 3.13.x from python.org.
2) If an old .venv folder exists after failed starts, delete it.
3) Run run_windows.bat or run_windows_ROBUST.bat.

This launcher searches real python.exe locations first and uses the py launcher only as a fallback.
It rejects Python 3.14 because some packages may not yet have stable wheels for it.
