EBAM G-code Studio v3.3 LINUX package.
Use run_linux.sh.
The application is local only: http://127.0.0.1:8501
