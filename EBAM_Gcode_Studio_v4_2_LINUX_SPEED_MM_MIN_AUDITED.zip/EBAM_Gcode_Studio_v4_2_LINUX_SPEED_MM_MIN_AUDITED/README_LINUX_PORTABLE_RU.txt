# EBAM G-Code Studio v4.2 — Linux Portable Prep

Эта версия добавляет подготовку переносимого Linux-запуска.

## Быстрый запуск обычным способом

```bash
chmod +x run_linux.sh
./run_linux.sh
```

## Portable-запуск с готовым .venv

На Linux-компьютере с интернетом:

```bash
chmod +x build_linux_portable.sh
./build_linux_portable.sh
./run_linux_PORTABLE.sh
```

После этого папку можно архивировать и переносить на похожий Linux-компьютер:

```bash
cd ..
tar -czf EBAM_Gcode_Studio_v4_1_LINUX_PORTABLE.tar.gz EBAM_Gcode_Studio_v4_1_LINUX_PORTABLE_PREP
```

## Offline-вариант через wheelhouse

На компьютере с интернетом:

```bash
./download_wheelhouse_linux.sh
```

Потом перенести папку на офлайн-компьютер и выполнить:

```bash
./install_from_wheelhouse_linux.sh
./run_linux_PORTABLE.sh
```

## Проверка Python

```bash
./check_linux_python.sh
```

## Экспериментально: PyInstaller onedir

```bash
./build_linux_pyinstaller_onedir.sh
```

Рекомендуемый вариант для пусконаладки: portable `.venv` или offline `wheelhouse`, потому что это стабильнее для Streamlit-приложения.

## Безопасность

Перед реальной наплавкой:
preview -> TEST Z10-15 мм -> просмотр G-code/audit -> сухой прогон без луча и проволоки -> проверка W-ретракта -> короткая наплавка -> полный файл.
