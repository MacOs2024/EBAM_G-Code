#!/usr/bin/env bash
set -e

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

PYTHON_BIN="${PYTHON_BIN:-python3}"

echo "Experimental PyInstaller onedir build for Linux."
echo "Recommended first: use build_linux_portable.sh"

if [ ! -d ".buildvenv" ]; then
  "$PYTHON_BIN" -m venv --copies .buildvenv
fi

./.buildvenv/bin/python -m pip install --upgrade pip wheel setuptools
./.buildvenv/bin/python -m pip install -r requirements.txt
./.buildvenv/bin/python -m pip install pyinstaller

./.buildvenv/bin/python -m PyInstaller \
  --noconfirm \
  --onedir \
  --name EBAM_Gcode_Studio_Linux_v4_1 \
  --collect-all streamlit \
  --collect-all pandas \
  --collect-all matplotlib \
  --collect-all shapely \
  --collect-all trimesh \
  desktop_launcher.py

echo
echo "Build result:"
echo "  dist/EBAM_Gcode_Studio_Linux_v4_1/"
