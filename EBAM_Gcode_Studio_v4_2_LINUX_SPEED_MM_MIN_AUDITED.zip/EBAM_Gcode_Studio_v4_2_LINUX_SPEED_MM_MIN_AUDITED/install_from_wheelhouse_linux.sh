#!/usr/bin/env bash
set -e

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

PYTHON_BIN="${PYTHON_BIN:-python3}"

if [ ! -d "wheelhouse" ]; then
  echo "ERROR: wheelhouse folder not found."
  echo "On an internet-connected Linux PC run:"
  echo "  ./download_wheelhouse_linux.sh"
  exit 1
fi

if [ ! -d ".venv" ]; then
  "$PYTHON_BIN" -m venv --copies .venv
fi

./.venv/bin/python -m pip install --upgrade pip wheel setuptools --no-index --find-links wheelhouse || true
./.venv/bin/python -m pip install --no-index --find-links wheelhouse -r requirements.txt

chmod +x run_linux_PORTABLE.sh

echo
echo "Offline portable environment installed."
echo "Start app:"
echo "  ./run_linux_PORTABLE.sh"
