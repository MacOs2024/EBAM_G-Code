#!/usr/bin/env bash
set -e

PYTHON_BIN="${PYTHON_BIN:-python3}"

echo "Python check"
echo "------------"
command -v "$PYTHON_BIN" || {
  echo "python3 not found"
  exit 1
}

"$PYTHON_BIN" --version
"$PYTHON_BIN" - <<'PY'
import sys, platform
print("Executable:", sys.executable)
print("Version:", sys.version)
print("Platform:", platform.platform())
print("OK Python >=3.10:", sys.version_info >= (3, 10))
PY

echo
echo "If venv module is missing on Ubuntu/Debian:"
echo "  sudo apt install python3-venv python3-pip"
