#!/usr/bin/env bash
set -e

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

PYTHON_BIN="${PYTHON_BIN:-python3}"

mkdir -p wheelhouse

echo "Downloading wheels into ./wheelhouse ..."
"$PYTHON_BIN" -m pip download -r requirements.txt -d wheelhouse

echo
echo "Wheelhouse ready."
echo "You can copy this folder to an offline Linux PC and run:"
echo "  ./install_from_wheelhouse_linux.sh"
