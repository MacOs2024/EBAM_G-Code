#!/usr/bin/env bash
set -e

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

if [ ! -x "$APP_DIR/.venv/bin/python" ]; then
  echo "ERROR: portable .venv not found."
  echo "Run first: ./build_linux_portable.sh"
  echo "Or offline: ./install_from_wheelhouse_linux.sh"
  exit 1
fi

"$APP_DIR/.venv/bin/python" -m streamlit run app.py \
  --server.address=127.0.0.1 \
  --server.port=8501 \
  --browser.gatherUsageStats=false
