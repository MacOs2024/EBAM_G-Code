#!/usr/bin/env bash
set -e

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

PYTHON_BIN="${PYTHON_BIN:-python3}"

echo "== EBAM G-Code Studio v4.2 Linux portable builder =="
echo "Using Python: $PYTHON_BIN"

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "ERROR: python3 not found."
  echo "Ubuntu/Debian: sudo apt install python3 python3-venv python3-pip"
  exit 1
fi

"$PYTHON_BIN" - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("ERROR: Python 3.10+ required")
print("Python OK:", sys.version)
PY

if [ -d ".venv" ]; then
  echo "Existing .venv found."
  read -r -p "Rebuild .venv? [y/N] " ans
  case "$ans" in
    y|Y|yes|YES) rm -rf .venv ;;
    *) echo "Keeping existing .venv" ;;
  esac
fi

if [ ! -d ".venv" ]; then
  "$PYTHON_BIN" -m venv --copies .venv
fi

./.venv/bin/python -m pip install --upgrade pip wheel setuptools
./.venv/bin/python -m pip install -r requirements.txt

chmod +x run_linux_PORTABLE.sh

echo
echo "Portable environment is ready."
echo "Start app:"
echo "  ./run_linux_PORTABLE.sh"
echo
echo "To pack folder:"
echo "  cd .."
echo "  tar -czf EBAM_Gcode_Studio_v4_1_LINUX_PORTABLE.tar.gz EBAM_Gcode_Studio_v4_1_LINUX_PORTABLE_PREP"
